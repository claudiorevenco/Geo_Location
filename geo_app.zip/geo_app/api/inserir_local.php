<?php
/**
 * @file inserir_local.php
 * @brief Insere um novo local na base de dados
 */
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

// Verificar autenticação
if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Não autenticado']);
    exit;
}

// Receber dados
$nome = trim($_POST['nome'] ?? '');
$categoria_id = intval($_POST['categoria_id'] ?? 0);
$cidade_id = intval($_POST['cidade_id'] ?? 0);
$morada = trim($_POST['morada'] ?? '');
$codigo_postal = trim($_POST['codigo_postal'] ?? '');
$latitude = floatval($_POST['latitude'] ?? 0);
$longitude = floatval($_POST['longitude'] ?? 0);
$telefone = trim($_POST['telefone'] ?? '');
$email = trim($_POST['email'] ?? '');
$website = trim($_POST['website'] ?? '');
$descricao_curta = trim($_POST['descricao_curta'] ?? '');
$descricao = trim($_POST['descricao'] ?? '');
$criado_por = $_SESSION['user_id'];

// Validações
if (empty($nome) || empty($categoria_id) || empty($cidade_id) || empty($morada) || empty($codigo_postal)) {
    echo json_encode(['success' => false, 'message' => 'Campos obrigatórios em falta']);
    exit;
}

if ($latitude == 0 || $longitude == 0) {
    echo json_encode(['success' => false, 'message' => 'Coordenadas inválidas']);
    exit;
}

// Gerar slug único
$slug = gerarSlug($nome, $pdo);

// Status: admin/publicador = ativo, normal = pendente
$status = (getUserType() === 'admin') ? 'ativo' : 'ativo';

try {
    $pdo->beginTransaction();

    // Inserir local
    $sql = "INSERT INTO locais (nome, slug, categoria_id, cidade_id, criado_por, status, 
                               morada, codigo_postal, telefone, email, website, 
                               latitude, longitude, descricao_curta, descricao)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $nome, $slug, $categoria_id, $cidade_id, $criado_por, $status,
        $morada, $codigo_postal, $telefone, $email, $website,
        $latitude, $longitude, $descricao_curta, $descricao
    ]);

    $local_id = $pdo->lastInsertId();

    // Processar foto se existir
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $resultado = uploadFoto($_FILES['foto']);
        if ($resultado['success']) {
            $stmt_foto = $pdo->prepare("INSERT INTO fotos (local_id, ficheiro, principal) VALUES (?, ?, 1)");
            $stmt_foto->execute([$local_id, $resultado['filename']]);
        }
    }

    $pdo->commit();

    echo json_encode([
        'success' => true, 
        'id' => $local_id,
        'message' => $status === 'pendente' ? 'Local submetido para aprovação' : 'Local criado com sucesso'
    ]);

} catch (PDOException $e) {
    $pdo->rollBack();
    error_log("Erro ao inserir local: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Erro ao guardar na base de dados']);
}
