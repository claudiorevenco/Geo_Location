<?php
/**
 * @file editar_local.php
 * @brief Atualiza um local existente
 */
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Não autenticado']);
    exit;
}

$id = intval($_POST['id'] ?? 0);
if (!$id) {
    echo json_encode(['success' => false, 'message' => 'ID inválido']);
    exit;
}

// Verificar permissões
if (!canEditLocal($id, $pdo)) {
    echo json_encode(['success' => false, 'message' => 'Sem permissão para editar']);
    exit;
}

// Receber dados
$nome = trim($_POST['nome'] ?? '');
$categoria_id = intval($_POST['categoria_id'] ?? 0);
$cidade_id = intval($_POST['cidade_id'] ?? 0);
$morada = trim($_POST['morada'] ?? '');
$codigo_postal = trim($_POST['codigo_postal'] ?? '');
$latitude = floatval($_POST['latitude'] ?? 0);
$longitude = floatval($_POST['longitude'] ?? 0);
$telefone = trim($_POST['telefone'] ?? '');
$email = trim($_POST['email'] ?? '');
$website = trim($_POST['website'] ?? '');
$descricao_curta = trim($_POST['descricao_curta'] ?? '');
$descricao = trim($_POST['descricao'] ?? '');
$atualizado_por = $_SESSION['user_id'];

// Validações
if (empty($nome) || empty($categoria_id) || empty($cidade_id) || empty($morada) || empty($codigo_postal)) {
    echo json_encode(['success' => false, 'message' => 'Campos obrigatórios em falta']);
    exit;
}

// Gerar novo slug
$slug = gerarSlug($nome, $pdo, 'locais', $id);

try {
    $pdo->beginTransaction();

    // Atualizar local
    $sql = "UPDATE locais SET 
                nome = ?, slug = ?, categoria_id = ?, cidade_id = ?, 
                morada = ?, codigo_postal = ?, telefone = ?, email = ?, website = ?,
                latitude = ?, longitude = ?, descricao_curta = ?, descricao = ?,
                atualizado_por = ?, atualizado_em = NOW()
            WHERE id = ?";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $nome, $slug, $categoria_id, $cidade_id,
        $morada, $codigo_postal, $telefone, $email, $website,
        $latitude, $longitude, $descricao_curta, $descricao,
        $atualizado_por, $id
    ]);

    // Processar nova foto se existir
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $resultado = uploadFoto($_FILES['foto']);
        if ($resultado['success']) {
            // Remover flag principal das fotos existentes
            $pdo->prepare("UPDATE fotos SET principal = 0 WHERE local_id = ?")->execute([$id]);

            // Inserir nova foto como principal
            $stmt_foto = $pdo->prepare("INSERT INTO fotos (local_id, ficheiro, principal) VALUES (?, ?, 1)");
            $stmt_foto->execute([$id, $resultado['filename']]);
        }
    }

    $pdo->commit();

    echo json_encode(['success' => true, 'message' => 'Local atualizado com sucesso']);

} catch (PDOException $e) {
    $pdo->rollBack();
    error_log("Erro ao editar local: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Erro ao atualizar na base de dados']);
}
