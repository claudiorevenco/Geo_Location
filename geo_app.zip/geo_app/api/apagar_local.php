<?php
/**
 * @file apagar_local.php
 * @brief Apaga um local e suas fotos
 */
require_once '../includes/config.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Não autenticado']);
    exit;
}

// Receber JSON
$input = json_decode(file_get_contents('php://input'), true);
$id = intval($input['id'] ?? 0);

if (!$id) {
    echo json_encode(['success' => false, 'message' => 'ID inválido']);
    exit;
}

// Verificar permissões
if (!canEditLocal($id, $pdo)) {
    echo json_encode(['success' => false, 'message' => 'Sem permissão para apagar']);
    exit;
}

try {
    // As fotos serão apagadas automaticamente por CASCADE
    $stmt = $pdo->prepare("DELETE FROM locais WHERE id = ?");
    $stmt->execute([$id]);

    echo json_encode(['success' => true, 'message' => 'Local apagado com sucesso']);
} catch (PDOException $e) {
    error_log("Erro ao apagar local: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Erro ao apagar da base de dados']);
}
