<?php
/**
 * @file get_locais.php
 * @brief Devolve todos os locais ativos com informações completas
 */
require_once '../includes/config.php';

header('Content-Type: application/json');

try {
    $sql = "SELECT l.id, l.nome, l.slug, l.morada, l.codigo_postal, l.telefone, l.email, l.website,
                   l.latitude, l.longitude, l.descricao_curta, l.descricao, l.criado_por,
                   l.categoria_id, l.cidade_id,
                   c.nome AS categoria, c.cor AS categoria_cor, c.letras AS categoria_letras, c.icone AS categoria_icone,
                   ci.nome AS cidade, p.nome_pt AS pais,
                   (SELECT f.ficheiro FROM fotos f WHERE f.local_id = l.id AND f.principal = 1 LIMIT 1) AS foto_principal
            FROM locais l
            JOIN categorias c ON l.categoria_id = c.id
            JOIN cidades ci ON l.cidade_id = ci.id
            JOIN paises p ON ci.pais_id = p.id
            WHERE l.status = 'ativo'
            ORDER BY l.criado_em DESC";

    $stmt = $pdo->query($sql);
    $locais = $stmt->fetchAll();

    echo json_encode($locais);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erro na base de dados']);
}
