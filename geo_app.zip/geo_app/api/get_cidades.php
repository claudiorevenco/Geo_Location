<?php
/**
 * @file get_cidades.php
 * @brief Devolve cidades de um país específico
 */
require_once '../includes/config.php';

header('Content-Type: application/json');

$pais_id = isset($_GET['pais_id']) ? intval($_GET['pais_id']) : 0;

if (!$pais_id) {
    echo json_encode([]);
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT id, nome FROM cidades WHERE pais_id = ? AND ativo = 1 ORDER BY nome");
    $stmt->execute([$pais_id]);
    $cidades = $stmt->fetchAll();
    echo json_encode($cidades);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erro na base de dados']);
}
