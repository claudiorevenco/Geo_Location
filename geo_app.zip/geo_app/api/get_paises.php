<?php
/**
 * @file get_paises.php
 * @brief Devolve lista de países ativos
 */
require_once '../includes/config.php';

header('Content-Type: application/json');

try {
    $stmt = $pdo->query("SELECT id, codigo_iso, nome_pt FROM paises WHERE ativo = 1 ORDER BY nome_pt");
    $paises = $stmt->fetchAll();
    echo json_encode($paises);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erro na base de dados']);
}
