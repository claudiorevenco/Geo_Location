<?php
/**
 * @file enviar_email.php
 * @brief Envia email com detalhes do local
 */
require_once '../includes/config.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$id = intval($input['id'] ?? 0);
$destino = trim($input['email'] ?? '');

if (!$id || !filter_var($destino, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'Dados inválidos']);
    exit;
}

// Buscar dados do local
$stmt = $pdo->prepare("SELECT l.nome, l.morada, l.telefone, l.email, l.website, 
                              l.latitude, l.longitude, l.descricao,
                              c.nome AS categoria, ci.nome AS cidade, p.nome_pt AS pais
                       FROM locais l
                       JOIN categorias c ON l.categoria_id = c.id
                       JOIN cidades ci ON l.cidade_id = ci.id
                       JOIN paises p ON ci.pais_id = p.id
                       WHERE l.id = ?");
$stmt->execute([$id]);
$local = $stmt->fetch();

if (!$local) {
    echo json_encode(['success' => false, 'message' => 'Local não encontrado']);
    exit;
}

// Enviar email
if (enviarEmailLocal($destino, $local)) {
    echo json_encode(['success' => true, 'message' => 'Email enviado com sucesso']);
} else {
    echo json_encode(['success' => false, 'message' => 'Falha ao enviar email']);
}
