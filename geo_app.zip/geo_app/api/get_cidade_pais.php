<?php
/**
 * @file get_cidade_pais.php
 * @brief Devolve o país de uma cidade específica
 */
require_once '../includes/config.php';

header('Content-Type: application/json');

$cidade_id = isset($_GET['cidade_id']) ? intval($_GET['cidade_id']) : 0;

if (!$cidade_id) {
    echo json_encode(['pais_id' => 0]);
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT pais_id FROM cidades WHERE id = ?");
    $stmt->execute([$cidade_id]);
    $pais_id = $stmt->fetchColumn();
    echo json_encode(['pais_id' => $pais_id ?: 0]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erro na base de dados']);
}
