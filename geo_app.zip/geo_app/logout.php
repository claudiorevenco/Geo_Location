<?php
/**
 * @file logout.php
 * @brief Termina a sessão do utilizador
 */

// Iniciar sessão para poder destruí-la
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Limpar todas as variáveis de sessão
$_SESSION = array();

// Destruir o cookie de sessão se existir
if (isset($_COOKIE[session_name()])) {
    setcookie(session_name(), '', time() - 3600, '/');
}

// Destruir a sessão
session_destroy();

// Redirecionar para login
header('Location: login.php');
exit;
