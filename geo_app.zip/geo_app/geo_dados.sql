-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 05-Mar-2026 às 11:28
-- Versão do servidor: 10.4.32-MariaDB
-- versão do PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `geo_dados`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `avaliacoes`
--

CREATE TABLE `avaliacoes` (
  `id` int(11) NOT NULL,
  `local_id` int(11) NOT NULL,
  `utilizador_id` int(11) NOT NULL,
  `classificacao` tinyint(3) UNSIGNED NOT NULL COMMENT '1-5 estrelas',
  `comentario` text DEFAULT NULL,
  `aprovado` tinyint(1) DEFAULT 1,
  `reportado` tinyint(1) DEFAULT 0,
  `motivo_reporte` varchar(255) DEFAULT NULL,
  `criado_em` datetime DEFAULT current_timestamp(),
  `atualizado_em` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Avaliações e comentários dos utilizadores';

-- --------------------------------------------------------

--
-- Estrutura da tabela `categorias`
--

CREATE TABLE `categorias` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL COMMENT 'URL amigável',
  `descricao` text DEFAULT NULL COMMENT 'Descrição da categoria',
  `cor` varchar(7) NOT NULL DEFAULT '#3498db' COMMENT 'Cor em hexadecimal para ícones',
  `icone` varchar(50) DEFAULT NULL COMMENT 'Classe do ícone (FontAwesome, etc.)',
  `letras` varchar(3) NOT NULL COMMENT 'Sigla para mapas',
  `ordem` int(11) DEFAULT 0 COMMENT 'Ordem de exibição',
  `ativo` tinyint(1) DEFAULT 1,
  `criado_em` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Categorias de locais com estilização visual';

--
-- Extraindo dados da tabela `categorias`
--

INSERT INTO `categorias` (`id`, `nome`, `slug`, `descricao`, `cor`, `icone`, `letras`, `ordem`, `ativo`, `criado_em`) VALUES
(1, 'Aeroporto', 'aeroporto', 'Aeroportos e terminais aéreos', '#3498db', 'fa-plane', 'A', 1, 1, '2026-03-03 19:09:13'),
(2, 'Esquadra', 'autoridade-policial', 'Esquadra de polícia e autoridades de segurança', '#2c3e50', 'fa-shield-alt', 'AP', 2, 1, '2026-03-03 19:09:13'),
(3, 'Hospital', 'hospital', 'Hospitais e centros hospitalares', '#e74c3c', 'fa-hospital', 'H', 3, 1, '2026-03-03 19:09:13'),
(4, 'Centro de Saúde', 'centro-saude', 'Centros de saúde e clínicas médicas', '#e67e22', 'fa-clinic-medical', 'CS', 4, 1, '2026-03-03 19:09:13'),
(5, 'Bombeiros', 'bombeiros', 'Corpos de bombeiros voluntários e profissionais', '#c0392b', 'fa-fire-extinguisher', 'B', 5, 1, '2026-03-03 19:09:13'),
(6, 'Proteção Civil', 'protecao-civil', 'Serviços de proteção civil e emergência', '#8e44ad', 'fa-exclamation-triangle', 'PC', 6, 1, '2026-03-03 19:09:13'),
(7, 'Hotel', 'hotel', 'Hotéis e resorts', '#2ecc71', 'fa-hotel', 'HT', 7, 1, '2026-03-03 19:09:13'),
(8, 'Alojamento Local', 'alojamento-local', 'Alojamentos locais e turismo rural', '#1abc9c', 'fa-home', 'AL', 8, 1, '2026-03-03 19:09:13'),
(9, 'Restaurante', 'restaurante', 'Restaurantes e estabelecimentos de refeições', '#d35400', 'fa-utensils', 'R', 9, 1, '2026-03-03 19:09:13'),
(10, 'Café / Bar', 'cafe-bar', 'Cafés, bares e esplanadas', '#6f4e37', 'fa-coffee', 'CB', 10, 1, '2026-03-03 19:09:13'),
(11, 'Museu', 'museu', 'Museus e galerias de arte', '#9b59b6', 'fa-landmark', 'M', 11, 1, '2026-03-03 19:09:13'),
(12, 'Sala de Espetáculos', 'sala-espetaculos', 'Teatros, cinemas e salas de concertos', '#34495e', 'fa-theater-masks', 'SE', 12, 1, '2026-03-03 19:09:13'),
(13, 'Câmara Municipal', 'camara-municipal', 'Edifícios municipais e serviços camarários', '#2980b9', 'fa-building', 'CM', 13, 1, '2026-03-03 19:09:13'),
(14, 'Junta de Freguesia', 'junta-freguesia', 'Juntas de freguesia e administração local', '#16a085', 'fa-landmark', 'JF', 14, 1, '2026-03-03 19:09:13'),
(15, 'Base Militar', 'base-militar', 'Instalações militares e quartéis', '#7f8c8d', 'fa-fighter-jet', 'BM', 15, 1, '2026-03-03 19:09:13'),
(16, 'Porto / Marinha', 'porto-marina', 'Portos comerciais e marinas desportivas', '#1f618d', 'fa-anchor', 'PM', 16, 1, '2026-03-03 19:09:13'),
(17, 'Órgãos de Comunicação Social', 'comunicacao-social', 'Estações de rádio, televisão e jornais', '#566573', 'fa-broadcast-tower', 'OCS', 17, 1, '2026-03-03 19:09:13'),
(18, 'Escola', 'escola', 'Escolas básicas e secundárias', '#f1c40f', 'fa-school', 'E', 18, 1, '2026-03-03 19:09:13'),
(19, 'Universidade', 'universidade', 'Universidades e institutos politécnicos', '#273746', 'fa-graduation-cap', 'U', 19, 1, '2026-03-03 19:09:13'),
(20, 'Farmácia', 'farmacia', 'Farmácias e parafarmácias', '#27ae60', 'fa-prescription-bottle-alt', 'F', 20, 1, '2026-03-03 19:09:13'),
(21, 'Supermercado', 'supermercado', 'Supermercados e hipermercados', '#f39c12', 'fa-shopping-cart', 'S', 21, 1, '2026-03-03 19:09:13'),
(22, 'Praia', 'praia', 'Praias e zonas balneares', '#f39c12', 'fa-umbrella-beach', 'P', 22, 1, '2026-03-03 19:09:13'),
(23, 'Parque Natural', 'parque-natural', 'Parques naturais e reservas', '#229954', 'fa-tree', 'PN', 23, 1, '2026-03-03 19:09:13'),
(24, 'Monumento', 'monumento', 'Monumentos históricos e património', '#8e44ad', 'fa-monument', 'MN', 24, 1, '2026-03-03 19:09:13'),
(25, 'Centro Comercial', 'centro-comercial', 'Centros comerciais e lojas', '#e74c3c', 'fa-shopping-bag', 'CC', 25, 1, '2026-03-03 19:09:13'),
(26, 'Estação de Comboios', 'estacao-comboios', 'Estações ferroviárias', '#34495e', 'fa-train', 'EC', 26, 1, '2026-03-03 19:09:13'),
(27, 'Terminal de Autocarros', 'terminal-autocarros', 'Terminais e estações de autocarros', '#5d6d7e', 'fa-bus', 'TA', 27, 1, '2026-03-03 19:09:13'),
(28, 'Outros', 'outros', 'Outros locais não categorizados', '#7f7f7f', 'fa-map-marker-alt', '?', 99, 1, '2026-03-03 19:09:13');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cidades`
--

CREATE TABLE `cidades` (
  `id` int(11) NOT NULL,
  `pais_id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `distrito_estado` varchar(100) DEFAULT NULL COMMENT 'Distrito, província ou estado',
  `codigo_postal_prefixo` varchar(10) DEFAULT NULL COMMENT 'Prefixo de código postal da cidade',
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `populacao` int(10) UNSIGNED DEFAULT NULL COMMENT 'População aproximada para ordenação',
  `ativo` tinyint(1) DEFAULT 1,
  `criado_em` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Catálogo de cidades normalizado';

--
-- Extraindo dados da tabela `cidades`
--

INSERT INTO `cidades` (`id`, `pais_id`, `nome`, `distrito_estado`, `codigo_postal_prefixo`, `latitude`, `longitude`, `populacao`, `ativo`, `criado_em`) VALUES
(1, 1, 'Lisboa', 'Lisboa', NULL, 38.72230000, -9.13930000, NULL, 1, '2026-03-03 19:09:13'),
(2, 1, 'Porto', 'Porto', NULL, 41.15790000, -8.62910000, NULL, 1, '2026-03-03 19:09:13'),
(3, 1, 'Sesimbra', 'Setúbal', NULL, 38.44400000, -9.10140000, NULL, 1, '2026-03-03 19:09:13'),
(4, 1, 'Faro', 'Faro', NULL, 37.01940000, -7.93220000, NULL, 1, '2026-03-03 19:09:13'),
(5, 1, 'Coimbra', 'Coimbra', NULL, 40.20330000, -8.41030000, NULL, 1, '2026-03-03 19:09:13'),
(6, 1, 'Braga', 'Braga', NULL, 41.54540000, -8.42650000, NULL, 1, '2026-03-03 19:09:13'),
(7, 1, 'Funchal', 'Madeira', NULL, 32.66690000, -16.92410000, NULL, 1, '2026-03-03 19:09:13'),
(8, 1, 'Ponta Delgada', 'Açores', NULL, 37.74210000, -25.65770000, NULL, 1, '2026-03-03 19:09:13'),
(9, 2, 'Madrid', 'Madrid', NULL, 40.41680000, -3.70380000, NULL, 1, '2026-03-03 19:09:13'),
(10, 2, 'Barcelona', 'Catalunha', NULL, 41.38510000, 2.17340000, NULL, 1, '2026-03-03 19:09:13'),
(11, 7, 'São Paulo', 'São Paulo', NULL, -23.55050000, -46.63330000, NULL, 1, '2026-03-03 19:09:13'),
(12, 7, 'Rio de Janeiro', 'Rio de Janeiro', NULL, -22.90680000, -43.17290000, NULL, 1, '2026-03-03 19:09:13');

-- --------------------------------------------------------

--
-- Estrutura da tabela `favoritos`
--

CREATE TABLE `favoritos` (
  `id` int(11) NOT NULL,
  `utilizador_id` int(11) NOT NULL,
  `local_id` int(11) NOT NULL,
  `notas_pessoais` text DEFAULT NULL COMMENT 'Notas privadas do utilizador',
  `criado_em` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Locais favoritos dos utilizadores';

-- --------------------------------------------------------

--
-- Estrutura da tabela `fotos`
--

CREATE TABLE `fotos` (
  `id` int(11) NOT NULL,
  `local_id` int(11) NOT NULL,
  `ficheiro` varchar(255) NOT NULL COMMENT 'Nome do ficheiro ou URL',
  `legenda` varchar(255) DEFAULT NULL,
  `ordem` int(11) DEFAULT 0 COMMENT 'Ordem de exibição',
  `principal` tinyint(1) DEFAULT 0 COMMENT 'Foto principal do local',
  `tamanho_bytes` int(10) UNSIGNED DEFAULT NULL,
  `largura_px` smallint(5) UNSIGNED DEFAULT NULL,
  `altura_px` smallint(5) UNSIGNED DEFAULT NULL,
  `tipo_mime` varchar(50) DEFAULT NULL,
  `enviado_por` int(11) DEFAULT NULL,
  `aprovada` tinyint(1) DEFAULT 1,
  `criado_em` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Fotos associadas aos locais (1 local = N fotos)';

--
-- Extraindo dados da tabela `fotos`
--

INSERT INTO `fotos` (`id`, `local_id`, `ficheiro`, `legenda`, `ordem`, `principal`, `tamanho_bytes`, `largura_px`, `altura_px`, `tipo_mime`, `enviado_por`, `aprovada`, `criado_em`) VALUES
(1, 1, 'camara-sesimbra-fachada.jpg', 'Fachada principal da Câmara Municipal', 1, 1, NULL, NULL, NULL, NULL, NULL, 1, '2026-03-03 19:09:13'),
(2, 1, 'camara-sesimbra-interior.jpg', 'Atendimento ao público', 2, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-03-03 19:09:13'),
(3, 2, 'bombeiros-sesimbra-edificio.jpg', 'Edifício dos Bombeiros Voluntários', 1, 1, NULL, NULL, NULL, NULL, NULL, 1, '2026-03-03 19:09:13'),
(4, 2, 'bombeiros-sesimbra-viaturas.jpg', 'Viaturas de emergência', 2, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-03-03 19:09:13'),
(5, 3, 'praia-california-vista.jpg', 'Vista panorâmica da Praia da Califórnia', 1, 1, NULL, NULL, NULL, NULL, NULL, 1, '2026-03-03 19:09:13'),
(6, 3, 'praia-california-mar.jpg', 'Águas cristalinas da praia', 2, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-03-03 19:09:13'),
(7, 3, 'praia-california-por-do-sol.jpg', 'Pôr do sol na Praia da Califórnia', 3, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-03-03 19:09:13'),
(8, 4, 'velho-mar-esplanada.jpg', 'Esplanada com vista para o mar', 1, 1, NULL, NULL, NULL, NULL, NULL, 1, '2026-03-03 19:09:13'),
(9, 4, 'velho-mar-prato.jpg', 'Especialidade em peixe fresco', 2, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-03-03 19:09:13'),
(11, 6, 'img_69a8993c162ae4.99771022.jpg', NULL, 0, 1, NULL, NULL, NULL, NULL, NULL, 1, '2026-03-04 20:42:36');

-- --------------------------------------------------------

--
-- Estrutura da tabela `horarios_funcionamento`
--

CREATE TABLE `horarios_funcionamento` (
  `id` int(11) NOT NULL,
  `local_id` int(11) NOT NULL,
  `dia_semana` tinyint(4) NOT NULL COMMENT '0=Domingo, 1=Segunda, ..., 6=Sábado',
  `hora_abertura` time DEFAULT NULL,
  `hora_fecho` time DEFAULT NULL,
  `fechado` tinyint(1) DEFAULT 0,
  `horario_continuo` tinyint(1) DEFAULT 0 COMMENT 'Sem intervalo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Horários de funcionamento semanais';

--
-- Extraindo dados da tabela `horarios_funcionamento`
--

INSERT INTO `horarios_funcionamento` (`id`, `local_id`, `dia_semana`, `hora_abertura`, `hora_fecho`, `fechado`, `horario_continuo`) VALUES
(1, 1, 1, '09:00:00', '17:00:00', 0, 0),
(2, 1, 2, '09:00:00', '17:00:00', 0, 0),
(3, 1, 3, '09:00:00', '17:00:00', 0, 0),
(4, 1, 4, '09:00:00', '17:00:00', 0, 0),
(5, 1, 5, '09:00:00', '16:00:00', 0, 0),
(6, 1, 6, NULL, NULL, 1, 0),
(7, 1, 0, NULL, NULL, 1, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `locais`
--

CREATE TABLE `locais` (
  `id` int(11) NOT NULL,
  `nome` varchar(150) NOT NULL,
  `slug` varchar(150) NOT NULL COMMENT 'URL amigável único',
  `categoria_id` int(11) NOT NULL,
  `cidade_id` int(11) NOT NULL,
  `criado_por` int(11) DEFAULT NULL,
  `atualizado_por` int(11) DEFAULT NULL,
  `status` enum('ativo','inativo','pendente','rejeitado') DEFAULT 'pendente',
  `morada` varchar(255) NOT NULL COMMENT 'Morada completa com código postal',
  `codigo_postal` varchar(20) NOT NULL COMMENT 'Código postal separado para pesquisa',
  `telefone` varchar(50) DEFAULT NULL,
  `telefone_alt` varchar(50) DEFAULT NULL COMMENT 'Telefone alternativo',
  `email` varchar(100) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `latitude` decimal(10,8) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  `descricao_curta` varchar(255) DEFAULT NULL COMMENT 'Resumo para listagens',
  `descricao` text DEFAULT NULL COMMENT 'Descrição completa (HTML permitido)',
  `meta_titulo` varchar(70) DEFAULT NULL,
  `meta_descricao` varchar(160) DEFAULT NULL,
  `palavras_chave` varchar(255) DEFAULT NULL,
  `destaque` tinyint(1) DEFAULT 0 COMMENT 'Aparece em destaque',
  `verificado` tinyint(1) DEFAULT 0 COMMENT 'Local verificado pelo admin',
  `visualizacoes` int(10) UNSIGNED DEFAULT 0,
  `classificacao_media` decimal(2,1) DEFAULT 0.0 COMMENT 'Média de 0-5',
  `total_avaliacoes` int(10) UNSIGNED DEFAULT 0,
  `criado_em` datetime DEFAULT current_timestamp(),
  `atualizado_em` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Locais georreferenciados com informação completa';

--
-- Extraindo dados da tabela `locais`
--

INSERT INTO `locais` (`id`, `nome`, `slug`, `categoria_id`, `cidade_id`, `criado_por`, `atualizado_por`, `status`, `morada`, `codigo_postal`, `telefone`, `telefone_alt`, `email`, `website`, `latitude`, `longitude`, `descricao_curta`, `descricao`, `meta_titulo`, `meta_descricao`, `palavras_chave`, `destaque`, `verificado`, `visualizacoes`, `classificacao_media`, `total_avaliacoes`, `criado_em`, `atualizado_em`) VALUES
(1, 'Câmara Municipal de Sesimbra', 'camara-municipal-sesimbra', 13, 3, NULL, NULL, 'ativo', 'Rua Amélia Frade, 2970-635 Sesimbra', '2970-635', '212288500', '212288501', 'geral@cm-sesimbra.pt', 'https://www.cm-sesimbra.pt', 38.44404000, -9.10143000, 'Edifício sede do município de Sesimbra, responsável pela administração local.', '<p>O edifício da Câmara Municipal de Sesimbra localiza-se no centro histórico da vila. Disponibiliza diversos serviços ao cidadão, incluindo atendimento ao público, licenciamentos e informação municipal.</p><p><strong>Horário de atendimento:</strong><br>Segunda a Sexta: 09:00 - 17:00</p>', 'Câmara Municipal de Sesimbra | Contactos e Serviços', 'Contactos e informações sobre a Câmara Municipal de Sesimbra. Morada, telefone, horário e serviços disponíveis.', NULL, 1, 1, 0, 0.0, 0, '2026-03-03 19:09:13', '2026-03-03 19:09:13'),
(2, 'Bombeiros Voluntários de Sesimbra', 'bombeiros-voluntarios-sesimbra', 5, 3, NULL, NULL, 'ativo', 'Rua 4 de Maio, 2970-657 Sesimbra', '2970-657', '212289130', '212289131', 'corpo.bombeiros@sapo.pt', 'https://www.bvsesimbra.pt', 38.44489000, -9.10391000, 'Corpo de bombeiros voluntários responsável pela proteção civil no concelho de Sesimbra.', '<p>Os Bombeiros Voluntários de Sesimbra prestam serviço de proteção e socorro há mais de 100 anos. Disponibilizam serviços de emergência médica, combate a incêndios e resgate.</p><p><strong>Emergência:</strong> 212 289 130</p>', 'Bombeiros Voluntários de Sesimbra | Emergência e Contactos', 'Contactos dos Bombeiros Voluntários de Sesimbra. Telefone de emergência, morada e serviços de proteção civil.', NULL, 0, 1, 0, 0.0, 0, '2026-03-03 19:09:13', '2026-03-03 19:09:13'),
(3, 'Praia da California', 'praia-da-california', 22, 3, NULL, NULL, 'ativo', 'Avenida da Liberdade, 2970-628 Sesimbra', '2970-628', NULL, NULL, NULL, NULL, 38.44320000, -9.09980000, 'Praia urbana de bandeira azul no centro de Sesimbra, ideal para famílias.', '<p>A Praia da Califórnia é uma das praias mais emblemáticas de Sesimbra. De bandeira azul, oferece águas calmas e transparentes, ideais para famílias com crianças. Possui equipamentos de apoio, nadador-salvador e acesso a pessoas com mobilidade reduzida.</p><p><strong>Instalações:</strong> Chuveiros, WC, bar, estacionamento.</p>', 'Praia da Califórnia Sesimbra | Bandeira Azul e Instalações', 'Informações sobre a Praia da Califórnia em Sesimbra. Bandeira azul, instalações, como chegar e fotos.', NULL, 1, 1, 0, 4.5, 2, '2026-03-03 19:09:13', '2026-03-03 19:09:13'),
(4, 'Restaurante O Velho e o Mar', 'restaurante-velho-e-o-mar-sesimbra', 9, 3, NULL, NULL, 'ativo', 'Rua Navegador Rodrigues Soromenho 1A, 2970-773 Sesimbra', '2970-773', '212289232', NULL, 'geral@ovelhoeomar.pt', 'https://www.ovelhoeomar.pt', 38.44345000, -9.10012000, 'Restaurante especializado em peixe e marisco fresco com vista para o mar.', '<p>O Restaurante O Velho e o Mar é conhecido pela qualidade do peixe e marisco fresco, pescado diariamente na costa de Sesimbra. O ambiente acolhedor e a vista panorâmica para o mar tornam-no ideal para refeições especiais.</p><p><strong>Especialidades:</strong> Caldeirada de peixe, Robalo assado, Arroz de marisco.</p>', 'Restaurante O Velho e o Mar Sesimbra | Peixe Fresco e Marisco', 'Restaurante em Sesimbra especializado em peixe e marisco fresco. Reservas, menu e contactos.', NULL, 0, 0, 0, 5.0, 2, '2026-03-03 19:09:13', '2026-03-03 19:09:13'),
(5, 'Telepizza', 'telepizza', 9, 3, NULL, NULL, 'pendente', 'Rua Piteira Santos, Nrº 11', '2975-330', '212 105 326', NULL, '', 'https://www.telepizza.pt', 38.56407063, -9.04007971, 'Telepizza Quinta do Conde', 'Horário:\r\n\r\nsegunda-feira	12:00–15:00, 18:00–23:00\r\nterça-feira	12:00–15:00, 18:00–23:00\r\nquarta-feira	12:00–15:00, 18:00–23:00\r\nquinta-feira	12:00–15:00, 18:00–23:00\r\nsexta-feira	12:00–00:00\r\nsábado	12:00–00:00\r\ndomingo	12:00–23:00', NULL, NULL, NULL, 0, 0, 0, 0.0, 0, '2026-03-04 20:34:20', '2026-03-04 20:34:20'),
(6, 'Telepizza Quinta do Conde', 'telepizza-quinta-do-conde', 9, 3, NULL, NULL, 'ativo', 'R. Piteira Santos Nº11', '2975-330', '212 105 326', NULL, '', 'https://www.telepizza.pt/', 38.56399513, -9.03994560, 'Telepizza Quinta do Conde', '<p> segunda-feira	12:00–15:00, 18:00–23:00 </p> \r\n<p> terça-feira	12:00–15:00, 18:00–23:00 </p>\r\n<p> quarta-feira	12:00–15:00, 18:00–23:00 </p>\r\n<p> quinta-feira	12:00–15:00, 18:00–23:00 </p>\r\n<p> sexta-feira	12:00–00:00 </p>\r\n<p> sábado	12:00–00:00 </p>\r\n<p> domingo	12:00–23:00 </p>', NULL, NULL, NULL, 0, 0, 0, 0.0, 0, '2026-03-04 20:42:36', '2026-03-05 08:24:51');

--
-- Acionadores `locais`
--
DELIMITER $$
CREATE TRIGGER `trg_locais_audit_insert` AFTER INSERT ON `locais` FOR EACH ROW BEGIN
    INSERT INTO logs_atividade (tabela_afetada, registro_id, acao, dados_novos)
    VALUES ('locais', NEW.id, 'INSERT', JSON_OBJECT(
        'nome', NEW.nome,
        'categoria_id', NEW.categoria_id,
        'cidade_id', NEW.cidade_id,
        'criado_por', NEW.criado_por
    ));
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trg_locais_audit_update` AFTER UPDATE ON `locais` FOR EACH ROW BEGIN
    INSERT INTO logs_atividade (tabela_afetada, registro_id, acao, dados_anteriores, dados_novos)
    VALUES ('locais', NEW.id, 'UPDATE', JSON_OBJECT(
        'nome', OLD.nome,
        'status', OLD.status,
        'atualizado_em', OLD.atualizado_em
    ), JSON_OBJECT(
        'nome', NEW.nome,
        'status', NEW.status,
        'atualizado_em', NEW.atualizado_em
    ));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `locais_tags`
--

CREATE TABLE `locais_tags` (
  `local_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `adicionado_por` int(11) DEFAULT NULL,
  `criado_em` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Relação muitos-para-muitos entre locais e tags';

--
-- Extraindo dados da tabela `locais_tags`
--

INSERT INTO `locais_tags` (`local_id`, `tag_id`, `adicionado_por`, `criado_em`) VALUES
(3, 1, NULL, '2026-03-03 19:09:13'),
(3, 6, NULL, '2026-03-03 19:09:13'),
(3, 9, NULL, '2026-03-03 19:09:13'),
(3, 13, NULL, '2026-03-03 19:09:13'),
(4, 6, NULL, '2026-03-03 19:09:13'),
(4, 8, NULL, '2026-03-03 19:09:13'),
(4, 15, NULL, '2026-03-03 19:09:13');

-- --------------------------------------------------------

--
-- Estrutura da tabela `logs_atividade`
--

CREATE TABLE `logs_atividade` (
  `id` int(11) NOT NULL,
  `tabela_afetada` varchar(50) NOT NULL,
  `registro_id` int(11) NOT NULL,
  `acao` enum('INSERT','UPDATE','DELETE') NOT NULL,
  `utilizador_id` int(11) DEFAULT NULL,
  `dados_anteriores` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`dados_anteriores`)),
  `dados_novos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`dados_novos`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `criado_em` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Auditoria de alterações na base de dados';

--
-- Extraindo dados da tabela `logs_atividade`
--

INSERT INTO `logs_atividade` (`id`, `tabela_afetada`, `registro_id`, `acao`, `utilizador_id`, `dados_anteriores`, `dados_novos`, `ip_address`, `user_agent`, `criado_em`) VALUES
(1, 'locais', 5, 'INSERT', NULL, NULL, '{\"nome\": \"Telepizza\", \"categoria_id\": 9, \"cidade_id\": 3, \"criado_por\": 6}', NULL, NULL, '2026-03-04 20:34:20'),
(2, 'locais', 6, 'INSERT', NULL, NULL, '{\"nome\": \"Telepizza Quinta do Conde\", \"categoria_id\": 9, \"cidade_id\": 3, \"criado_por\": 6}', NULL, NULL, '2026-03-04 20:42:36'),
(3, 'locais', 6, 'UPDATE', NULL, '{\"nome\": \"Telepizza Quinta do Conde\", \"status\": \"ativo\", \"atualizado_em\": \"2026-03-04 20:42:36\"}', '{\"nome\": \"Telepizza Quinta do Conde\", \"status\": \"ativo\", \"atualizado_em\": \"2026-03-04 20:44:01\"}', NULL, NULL, '2026-03-04 20:44:01'),
(4, 'locais', 6, 'UPDATE', NULL, '{\"nome\": \"Telepizza Quinta do Conde\", \"status\": \"ativo\", \"atualizado_em\": \"2026-03-04 20:44:01\"}', '{\"nome\": \"Telepizza Quinta do Conde\", \"status\": \"ativo\", \"atualizado_em\": \"2026-03-05 08:23:59\"}', NULL, NULL, '2026-03-05 08:23:59'),
(5, 'locais', 6, 'UPDATE', NULL, '{\"nome\": \"Telepizza Quinta do Conde\", \"status\": \"ativo\", \"atualizado_em\": \"2026-03-05 08:23:59\"}', '{\"nome\": \"Telepizza Quinta do Conde\", \"status\": \"ativo\", \"atualizado_em\": \"2026-03-05 08:24:51\"}', NULL, NULL, '2026-03-05 08:24:51');

-- --------------------------------------------------------

--
-- Estrutura da tabela `paises`
--

CREATE TABLE `paises` (
  `id` int(11) NOT NULL,
  `codigo_iso` char(2) NOT NULL COMMENT 'Código ISO 3166-1 alpha-2 (ex: PT, ES, FR)',
  `nome` varchar(100) NOT NULL,
  `nome_pt` varchar(100) NOT NULL COMMENT 'Nome do país em português',
  `continente` enum('Europa','Ásia','América do Norte','América do Sul','África','Oceania','Antártida') NOT NULL,
  `ativo` tinyint(1) DEFAULT 1,
  `criado_em` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Catálogo de países normalizado';

--
-- Extraindo dados da tabela `paises`
--

INSERT INTO `paises` (`id`, `codigo_iso`, `nome`, `nome_pt`, `continente`, `ativo`, `criado_em`) VALUES
(1, 'PT', 'Portugal', 'Portugal', 'Europa', 1, '2026-03-03 19:09:13'),
(2, 'ES', 'Spain', 'Espanha', 'Europa', 1, '2026-03-03 19:09:13'),
(3, 'FR', 'France', 'França', 'Europa', 1, '2026-03-03 19:09:13'),
(4, 'IT', 'Italy', 'Itália', 'Europa', 1, '2026-03-03 19:09:13'),
(5, 'DE', 'Germany', 'Alemanha', 'Europa', 1, '2026-03-03 19:09:13'),
(6, 'GB', 'United Kingdom', 'Reino Unido', 'Europa', 1, '2026-03-03 19:09:13'),
(7, 'BR', 'Brazil', 'Brasil', 'América do Sul', 1, '2026-03-03 19:09:13'),
(8, 'AO', 'Angola', 'Angola', 'África', 1, '2026-03-03 19:09:13'),
(9, 'MZ', 'Mozambique', 'Moçambique', 'África', 1, '2026-03-03 19:09:13'),
(10, 'CV', 'Cape Verde', 'Cabo Verde', 'África', 1, '2026-03-03 19:09:13'),
(11, 'US', 'United States', 'Estados Unidos', 'América do Norte', 1, '2026-03-03 19:09:13');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tags`
--

CREATE TABLE `tags` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `cor` varchar(7) DEFAULT '#95a5a6',
  `usos` int(10) UNSIGNED DEFAULT 0 COMMENT 'Contador de utilizações',
  `criado_em` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Etiquetas para categorização flexível';

--
-- Extraindo dados da tabela `tags`
--

INSERT INTO `tags` (`id`, `nome`, `slug`, `cor`, `usos`, `criado_em`) VALUES
(1, 'Acessível a cadeiras de rodas', 'acessivel-cadeiras-rodas', '#27ae60', 1, '2026-03-03 19:09:13'),
(2, 'Wi-Fi Gratuito', 'wifi-gratuito', '#3498db', 0, '2026-03-03 19:09:13'),
(3, 'Estacionamento', 'estacionamento', '#f39c12', 0, '2026-03-03 19:09:13'),
(4, 'Ar Condicionado', 'ar-condicionado', '#85c1e9', 0, '2026-03-03 19:09:13'),
(5, 'Pet Friendly', 'pet-friendly', '#e67e22', 0, '2026-03-03 19:09:13'),
(6, 'Vista Mar', 'vista-mar', '#1abc9c', 2, '2026-03-03 19:09:13'),
(7, 'Histórico', 'historico', '#8e44ad', 0, '2026-03-03 19:09:13'),
(8, 'Romântico', 'romantico', '#e91e63', 1, '2026-03-03 19:09:13'),
(9, 'Família', 'familia', '#2ecc71', 1, '2026-03-03 19:09:13'),
(10, 'Negócios', 'negocios', '#34495e', 0, '2026-03-03 19:09:13'),
(11, 'Económico', 'economico', '#27ae60', 0, '2026-03-03 19:09:13'),
(12, 'Luxo', 'luxo', '#f1c40f', 0, '2026-03-03 19:09:13'),
(13, 'Pôr do Sol', 'por-do-sol', '#e74c3c', 1, '2026-03-03 19:09:13'),
(14, 'Atividades ao Ar Livre', 'atividades-ar-livre', '#229954', 0, '2026-03-03 19:09:13'),
(15, 'Gastronomia Local', 'gastronomia-local', '#d35400', 1, '2026-03-03 19:09:13');

-- --------------------------------------------------------

--
-- Estrutura da tabela `utilizadores`
--

CREATE TABLE `utilizadores` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `senha` varchar(255) NOT NULL COMMENT 'Hash bcrypt da password',
  `tipo` enum('admin','editor','normal') NOT NULL DEFAULT 'normal',
  `avatar` varchar(255) DEFAULT NULL COMMENT 'Foto de perfil',
  `telefone` varchar(20) DEFAULT NULL,
  `ultimo_acesso` datetime DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT 1,
  `email_verificado` tinyint(1) DEFAULT 0,
  `token_recuperacao` varchar(100) DEFAULT NULL COMMENT 'Token para recuperação de password',
  `token_expira` datetime DEFAULT NULL,
  `criado_em` datetime DEFAULT current_timestamp(),
  `atualizado_em` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Utilizadores do sistema com diferentes níveis de acesso';

--
-- Extraindo dados da tabela `utilizadores`
--

INSERT INTO `utilizadores` (`id`, `nome`, `email`, `senha`, `tipo`, `avatar`, `telefone`, `ultimo_acesso`, `ativo`, `email_verificado`, `token_recuperacao`, `token_expira`, `criado_em`, `atualizado_em`) VALUES
(7, 'Administrador Sistema', 'admin@geodados.pt', '069b45c1df3183b7c3a8d95626582e4e39c0d80293beb1e066cc3153a8a44e9f:20b79bff33a6487a4162fd0ae32cab69b105c91f68b255b90138eb60d095b6b894040d6ab5ff2339a689bd803cca46043d4db8eb3950e5cb8f0b366e999c36ce', 'admin', NULL, NULL, NULL, 1, 0, NULL, NULL, '2026-03-05 08:43:35', '2026-03-05 08:43:53'),
(8, 'Cláudio Revenco', 'claudiorevenco@geodados.pt', 'fcd64849fd898746f47e18e7ff630443c2e4e40623ef3495351801db76600231:09918552830d06fc0ba3338461c7d292a32c978b81c6b8fd35eeaccf201abc6429ea2ce9c9bca2a9f41b6362c40bc8ba111e5d7ae540e34b422aee542fcb85eb', 'normal', NULL, NULL, NULL, 1, 0, NULL, NULL, '2026-03-05 08:45:47', '2026-03-05 09:17:30');

-- --------------------------------------------------------

--
-- Estrutura stand-in para vista `vw_locais_completos`
-- (Veja abaixo para a view atual)
--
CREATE TABLE `vw_locais_completos` (
`id` int(11)
,`nome` varchar(150)
,`slug` varchar(150)
,`morada` varchar(255)
,`codigo_postal` varchar(20)
,`telefone` varchar(50)
,`email` varchar(100)
,`website` varchar(150)
,`latitude` decimal(10,8)
,`longitude` decimal(11,8)
,`descricao_curta` varchar(255)
,`descricao` text
,`classificacao_media` decimal(2,1)
,`total_avaliacoes` int(10) unsigned
,`destaque` tinyint(1)
,`verificado` tinyint(1)
,`status` enum('ativo','inativo','pendente','rejeitado')
,`categoria` varchar(100)
,`categoria_cor` varchar(7)
,`categoria_icone` varchar(50)
,`cidade` varchar(100)
,`pais` varchar(100)
,`criado_por_nome` varchar(100)
,`foto_principal` varchar(255)
);

-- --------------------------------------------------------

--
-- Estrutura stand-in para vista `vw_locais_por_cidade_categoria`
-- (Veja abaixo para a view atual)
--
CREATE TABLE `vw_locais_por_cidade_categoria` (
`pais` varchar(100)
,`cidade` varchar(100)
,`categoria` varchar(100)
,`total_locais` bigint(21)
);

-- --------------------------------------------------------

--
-- Estrutura para vista `vw_locais_completos`
--
DROP TABLE IF EXISTS `vw_locais_completos`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_locais_completos`  AS SELECT `l`.`id` AS `id`, `l`.`nome` AS `nome`, `l`.`slug` AS `slug`, `l`.`morada` AS `morada`, `l`.`codigo_postal` AS `codigo_postal`, `l`.`telefone` AS `telefone`, `l`.`email` AS `email`, `l`.`website` AS `website`, `l`.`latitude` AS `latitude`, `l`.`longitude` AS `longitude`, `l`.`descricao_curta` AS `descricao_curta`, `l`.`descricao` AS `descricao`, `l`.`classificacao_media` AS `classificacao_media`, `l`.`total_avaliacoes` AS `total_avaliacoes`, `l`.`destaque` AS `destaque`, `l`.`verificado` AS `verificado`, `l`.`status` AS `status`, `c`.`nome` AS `categoria`, `c`.`cor` AS `categoria_cor`, `c`.`icone` AS `categoria_icone`, `ci`.`nome` AS `cidade`, `p`.`nome_pt` AS `pais`, `u`.`nome` AS `criado_por_nome`, (select `f`.`ficheiro` from `fotos` `f` where `f`.`local_id` = `l`.`id` and `f`.`principal` = 1 limit 1) AS `foto_principal` FROM ((((`locais` `l` join `categorias` `c` on(`l`.`categoria_id` = `c`.`id`)) join `cidades` `ci` on(`l`.`cidade_id` = `ci`.`id`)) join `paises` `p` on(`ci`.`pais_id` = `p`.`id`)) left join `utilizadores` `u` on(`l`.`criado_por` = `u`.`id`)) ;

-- --------------------------------------------------------

--
-- Estrutura para vista `vw_locais_por_cidade_categoria`
--
DROP TABLE IF EXISTS `vw_locais_por_cidade_categoria`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_locais_por_cidade_categoria`  AS SELECT `p`.`nome_pt` AS `pais`, `ci`.`nome` AS `cidade`, `c`.`nome` AS `categoria`, count(`l`.`id`) AS `total_locais` FROM (((`locais` `l` join `cidades` `ci` on(`l`.`cidade_id` = `ci`.`id`)) join `paises` `p` on(`ci`.`pais_id` = `p`.`id`)) join `categorias` `c` on(`l`.`categoria_id` = `c`.`id`)) WHERE `l`.`status` = 'ativo' GROUP BY `p`.`nome_pt`, `ci`.`nome`, `c`.`nome` ;

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `avaliacoes`
--
ALTER TABLE `avaliacoes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_local_user` (`local_id`,`utilizador_id`) COMMENT 'Um utilizador avalia uma vez',
  ADD KEY `utilizador_id` (`utilizador_id`),
  ADD KEY `idx_classificacao` (`classificacao`),
  ADD KEY `idx_aprovado` (`aprovado`);

--
-- Índices para tabela `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nome` (`nome`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Índices para tabela `cidades`
--
ALTER TABLE `cidades`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_cidade_pais` (`nome`,`pais_id`),
  ADD KEY `pais_id` (`pais_id`);

--
-- Índices para tabela `favoritos`
--
ALTER TABLE `favoritos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_user_local` (`utilizador_id`,`local_id`),
  ADD KEY `local_id` (`local_id`);

--
-- Índices para tabela `fotos`
--
ALTER TABLE `fotos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `enviado_por` (`enviado_por`),
  ADD KEY `idx_local_ordem` (`local_id`,`ordem`),
  ADD KEY `idx_principal` (`local_id`,`principal`);

--
-- Índices para tabela `horarios_funcionamento`
--
ALTER TABLE `horarios_funcionamento`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uk_local_dia` (`local_id`,`dia_semana`);

--
-- Índices para tabela `locais`
--
ALTER TABLE `locais`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD KEY `criado_por` (`criado_por`),
  ADD KEY `atualizado_por` (`atualizado_por`),
  ADD KEY `idx_categoria` (`categoria_id`),
  ADD KEY `idx_cidade` (`cidade_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_coordenadas` (`latitude`,`longitude`),
  ADD KEY `idx_destaque` (`destaque`);
ALTER TABLE `locais` ADD FULLTEXT KEY `ft_nome_desc` (`nome`,`descricao_curta`,`descricao`);

--
-- Índices para tabela `locais_tags`
--
ALTER TABLE `locais_tags`
  ADD PRIMARY KEY (`local_id`,`tag_id`),
  ADD KEY `tag_id` (`tag_id`),
  ADD KEY `adicionado_por` (`adicionado_por`);

--
-- Índices para tabela `logs_atividade`
--
ALTER TABLE `logs_atividade`
  ADD PRIMARY KEY (`id`),
  ADD KEY `utilizador_id` (`utilizador_id`),
  ADD KEY `idx_tabela_registro` (`tabela_afetada`,`registro_id`),
  ADD KEY `idx_data` (`criado_em`);

--
-- Índices para tabela `paises`
--
ALTER TABLE `paises`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `codigo_iso` (`codigo_iso`),
  ADD UNIQUE KEY `nome` (`nome`);

--
-- Índices para tabela `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nome` (`nome`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Índices para tabela `utilizadores`
--
ALTER TABLE `utilizadores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `avaliacoes`
--
ALTER TABLE `avaliacoes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT de tabela `cidades`
--
ALTER TABLE `cidades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de tabela `favoritos`
--
ALTER TABLE `favoritos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `fotos`
--
ALTER TABLE `fotos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de tabela `horarios_funcionamento`
--
ALTER TABLE `horarios_funcionamento`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `locais`
--
ALTER TABLE `locais`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `logs_atividade`
--
ALTER TABLE `logs_atividade`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `paises`
--
ALTER TABLE `paises`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de tabela `tags`
--
ALTER TABLE `tags`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de tabela `utilizadores`
--
ALTER TABLE `utilizadores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `avaliacoes`
--
ALTER TABLE `avaliacoes`
  ADD CONSTRAINT `avaliacoes_ibfk_1` FOREIGN KEY (`local_id`) REFERENCES `locais` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `avaliacoes_ibfk_2` FOREIGN KEY (`utilizador_id`) REFERENCES `utilizadores` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `cidades`
--
ALTER TABLE `cidades`
  ADD CONSTRAINT `cidades_ibfk_1` FOREIGN KEY (`pais_id`) REFERENCES `paises` (`id`);

--
-- Limitadores para a tabela `favoritos`
--
ALTER TABLE `favoritos`
  ADD CONSTRAINT `favoritos_ibfk_1` FOREIGN KEY (`utilizador_id`) REFERENCES `utilizadores` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `favoritos_ibfk_2` FOREIGN KEY (`local_id`) REFERENCES `locais` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `fotos`
--
ALTER TABLE `fotos`
  ADD CONSTRAINT `fotos_ibfk_1` FOREIGN KEY (`local_id`) REFERENCES `locais` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fotos_ibfk_2` FOREIGN KEY (`enviado_por`) REFERENCES `utilizadores` (`id`) ON DELETE SET NULL;

--
-- Limitadores para a tabela `horarios_funcionamento`
--
ALTER TABLE `horarios_funcionamento`
  ADD CONSTRAINT `horarios_funcionamento_ibfk_1` FOREIGN KEY (`local_id`) REFERENCES `locais` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `locais`
--
ALTER TABLE `locais`
  ADD CONSTRAINT `locais_ibfk_1` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`),
  ADD CONSTRAINT `locais_ibfk_2` FOREIGN KEY (`cidade_id`) REFERENCES `cidades` (`id`),
  ADD CONSTRAINT `locais_ibfk_3` FOREIGN KEY (`criado_por`) REFERENCES `utilizadores` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `locais_ibfk_4` FOREIGN KEY (`atualizado_por`) REFERENCES `utilizadores` (`id`) ON DELETE SET NULL;

--
-- Limitadores para a tabela `locais_tags`
--
ALTER TABLE `locais_tags`
  ADD CONSTRAINT `locais_tags_ibfk_1` FOREIGN KEY (`local_id`) REFERENCES `locais` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `locais_tags_ibfk_2` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `locais_tags_ibfk_3` FOREIGN KEY (`adicionado_por`) REFERENCES `utilizadores` (`id`) ON DELETE SET NULL;

--
-- Limitadores para a tabela `logs_atividade`
--
ALTER TABLE `logs_atividade`
  ADD CONSTRAINT `logs_atividade_ibfk_1` FOREIGN KEY (`utilizador_id`) REFERENCES `utilizadores` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
