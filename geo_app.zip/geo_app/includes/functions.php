<?php
/**
 * @file functions.php
 * @brief Funções auxiliares
 */

require_once __DIR__ . '/../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

/**
 * Upload de foto com validação completa
 */
function uploadFoto($file, $max_size = 2097152) {
    $target_dir = __DIR__ . "/../uploads/";

    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    $imageFileType = strtolower(pathinfo($file["name"], PATHINFO_EXTENSION));
    $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

    if (!in_array($imageFileType, $allowed)) {
        return ['success' => false, 'error' => 'Tipo de ficheiro não permitido'];
    }

    if ($file["size"] > $max_size) {
        return ['success' => false, 'error' => 'Ficheiro muito grande (max 2MB)'];
    }

    $check = getimagesize($file["tmp_name"]);
    if ($check === false) {
        return ['success' => false, 'error' => 'Ficheiro não é uma imagem válida'];
    }

    $new_filename = uniqid('img_', true) . "." . $imageFileType;
    $target_file = $target_dir . $new_filename;

    if (move_uploaded_file($file["tmp_name"], $target_file)) {
        return ['success' => true, 'filename' => $new_filename];
    }

    return ['success' => false, 'error' => 'Erro ao mover ficheiro'];
}

/**
 * Gerar slug único
 */
function gerarSlug($texto, $pdo, $tabela = 'locais', $id_excluir = null) {
    $slug = preg_replace('/[^a-z0-9]+/i', '-', strtolower($texto));
    $slug = trim($slug, '-');
    $slug_original = $slug;
    $contador = 1;

    while (true) {
        $sql = "SELECT id FROM $tabela WHERE slug = ?";
        $params = [$slug];

        if ($id_excluir) {
            $sql .= " AND id != ?";
            $params[] = $id_excluir;
        }

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        if (!$stmt->fetch()) {
            return $slug;
        }

        $slug = $slug_original . '-' . $contador;
        $contador++;
    }
}

/**
 * Constrói o corpo HTML do email
 */
function construirCorpoEmail(array $local): string
{
    // Link oficial e mais seguro do Google Maps
    $mapsLink = "https://www.google.com/maps/search/?api=1&query={$local['latitude']},{$local['longitude']}";
    
    return "
    <!DOCTYPE html>
    <html lang='pt'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <style>
            /* Reset e Base */
            body { 
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; 
                line-height: 1.6; 
                color: #334155; 
                background-color: #f1f5f9; 
                margin: 0; 
                padding: 40px 20px; 
            }
            .wrapper { 
                max-width: 600px; 
                margin: 0 auto; 
                background-color: #ffffff; 
                border-radius: 12px; 
                overflow: hidden; 
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03); 
            }
            
            /* Cabeçalho Premium */
            .header { 
                background-color: #1e293b; /* Ardósia escuro elegante */
                color: #ffffff; 
                padding: 40px 30px; 
                text-align: center; 
            }
            .header h1 { 
                margin: 0 0 8px 0; 
                font-size: 26px; 
                font-weight: 600; 
                letter-spacing: -0.5px;
            }
            .header p { 
                margin: 0; 
                color: #94a3b8; 
                font-size: 14px; 
                letter-spacing: 0.5px;
            }
            
            /* Corpo do Email */
            .content { 
                padding: 40px 30px; 
            }
            
            /* Linhas de Informação Limpas */
            .info-row { 
                padding: 16px 0; 
                border-bottom: 1px solid #e2e8f0; 
            }
            .info-row:last-of-type { 
                border-bottom: none; 
                margin-bottom: 20px;
            }
            .label { 
                color: #64748b; 
                font-size: 11px; 
                font-weight: 700; 
                text-transform: uppercase; 
                letter-spacing: 1.2px; 
                margin-bottom: 4px; 
            }
            .value { 
                color: #0f172a; 
                font-size: 16px; 
            }
            .value a { 
                color: #2563eb; 
                text-decoration: none; 
            }
            .value a:hover {
                text-decoration: underline;
            }
            .description-box {
                background-color: #f8fafc;
                padding: 20px;
                border-radius: 8px;
                margin-top: 10px;
                font-size: 15px;
                color: #475569;
                border-left: 4px solid #cbd5e1;
            }
            
            /* Botão de Ação */
            .btn-container { 
                text-align: center; 
                margin-top: 35px; 
            }
            .btn { 
                display: inline-block; 
                background-color: #2563eb; 
                color: #ffffff !important; 
                padding: 14px 32px; 
                text-decoration: none; 
                border-radius: 8px; 
                font-weight: 600; 
                font-size: 15px;
                transition: background-color 0.2s;
            }
            
            /* Rodapé */
            .footer { 
                text-align: center; 
                padding: 20px; 
                color: #94a3b8; 
                font-size: 13px; 
                background-color: #f8fafc;
                border-top: 1px solid #e2e8f0;
            }
        </style>
    </head>
    <body>
        <div class='wrapper'>
            <div class='header'>
                <h1>📍 " . htmlspecialchars($local['nome']) . "</h1>
                <p>" . htmlspecialchars($local['categoria']) . " &bull; " . htmlspecialchars($local['cidade']) . ", " . htmlspecialchars($local['pais']) . "</p>
            </div>
            
            <div class='content'>
                
                <div class='info-row'>
                    <div class='label'>Morada</div>
                    <div class='value'>" . htmlspecialchars($local['morada']) . "</div>
                </div>
                
                " . (!empty($local['telefone']) ? "
                <div class='info-row'>
                    <div class='label'>Telefone</div>
                    <div class='value'><a href='tel:{$local['telefone']}'>{$local['telefone']}</a></div>
                </div>" : "") . "
                
                " . (!empty($local['email']) ? "
                <div class='info-row'>
                    <div class='label'>Email</div>
                    <div class='value'><a href='mailto:{$local['email']}'>" . htmlspecialchars($local['email']) . "</a></div>
                </div>" : "") . "
                
                " . (!empty($local['website']) ? "
                <div class='info-row'>
                    <div class='label'>Website</div>
                    <div class='value'><a href='{$local['website']}' target='_blank'>" . htmlspecialchars($local['website']) . "</a></div>
                </div>" : "") . "
                
                " . (!empty($local['descricao']) ? "
                <div class='info-row'>
                    <div class='label'>Descrição</div>
                    <div class='description-box'>" . nl2br(htmlspecialchars($local['descricao'])) . "</div>
                </div>" : "") . "
                
                <div class='btn-container'>
                    <a href='{$mapsLink}' class='btn' target='_blank'>Abrir no Google Maps</a>
                </div>
                
            </div>
            
            <div class='footer'>
                Enviado por <strong>GeoLocation</strong>
            </div>
        </div>
    </body>
    </html>";
}

/**
 * Constrói versão texto simples do email
 */
function construirCorpoTexto(array $local): string
{
    $mapsLink = "https://www.google.com/maps/search/?api=1&query={$local['latitude']},{$local['longitude']}";
    
    $texto = "📍 " . strtoupper($local['nome']) . "\n";
    $texto .= "{$local['categoria']} | {$local['cidade']}, {$local['pais']}\n";
    $texto .= str_repeat("-", 40) . "\n\n";
    
    $texto .= "MORADA:\n{$local['morada']}\n\n";
    
    if (!empty($local['telefone'])) {
        $texto .= "TELEFONE:\n{$local['telefone']}\n\n";
    }
    if (!empty($local['email'])) {
        $texto .= "EMAIL:\n{$local['email']}\n\n";
    }
    if (!empty($local['website'])) {
        $texto .= "WEBSITE:\n{$local['website']}\n\n";
    }
    if (!empty($local['descricao'])) {
        $texto .= "DESCRIÇÃO:\n{$local['descricao']}\n\n";
    }
    
    $texto .= str_repeat("-", 40) . "\n";
    $texto .= "🗺️ VER NO GOOGLE MAPS:\n{$mapsLink}\n\n";
    $texto .= "Enviado por GeoLocation";
    
    return $texto;
}

/**
 * Envia email com detalhes do local usando PHPMailer
 * (SUBSTITUI a função antiga mail())
 */
function enviarEmailLocal(string $destino, array $local): bool
{
    $mail = new PHPMailer(true);
    
    try {
        // Configurações do servidor SMTP
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'geo.location.suporte@gmail.com';
        $mail->Password   = 'tzgp qibj sfne dfqc'; // Password de app
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        
        // DEBUG (descomenta para ver erros detalhados)
        //$mail->SMTPDebug = SMTP::DEBUG_SERVER;
        
        // Codificação
        $mail->CharSet = 'UTF-8';
        
        // Remetente e destinatário
        $mail->setFrom('geo.location.suporte@gmail.com', 'GeoLocation');
        $mail->addAddress($destino);
        
        // Conteúdo
        $mail->isHTML(true);
        $mail->Subject = '📍 ' . $local['nome'] . ' - GeoLocation';
        $mail->Body    = construirCorpoEmail($local);
        $mail->AltBody = construirCorpoTexto($local);
        
        $mail->send();
        return true;
        
    } catch (Exception $e) {
        error_log("Erro PHPMailer: " . $mail->ErrorInfo);
        return false;
    }
}
?>