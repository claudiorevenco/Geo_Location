<?php
/**
 * @file hash.php
 * @brief Funções de hashing SHA3-512 com salt
 */

/**
 * Gera um salt aleatório seguro
 */
function gerarSalt(int $tamanho = 32): string {
    return bin2hex(random_bytes($tamanho));
}

/**
 * Cria hash SHA3-512 da password com salt
 * Formato: salt:hash
 */
function hashPassword(string $senha): string {
    $salt = gerarSalt();
    $hash = hash('sha3-512', $senha . $salt);
    return $salt . ':' . $hash;
}

/**
 * Verifica se a senha corresponde ao hash armazenado
 * O hash armazenado deve estar no formato: salt:hash
 */
function verifyPassword(string $senha, string $hashArmazenado): bool {
    // Separar salt do hash
    $partes = explode(':', $hashArmazenado);
    
    if (count($partes) !== 2) {
        return false;
    }
    
    list($salt, $hashOriginal) = $partes;
    
    // Calcular hash da senha fornecida com o mesmo salt
    $hashCalculado = hash('sha3-512', $senha . $salt);
    
    // Comparar de forma segura (timing-safe)
    return hash_equals($hashOriginal, $hashCalculado);
}

/**
 * Verifica se uma string parece ser um hash SHA3 (formato salt:hash)
 */
function isHashSHA3(string $string): bool {
    $partes = explode(':', $string);
    if (count($partes) !== 2) {
        return false;
    }
    // Salt = 64 chars (hex de 32 bytes), Hash = 128 chars (hex de 64 bytes SHA3-512)
    return strlen($partes[0]) === 64 && strlen($partes[1]) === 128;
}