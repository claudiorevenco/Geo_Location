<?php
/**
 * @file config.php
 * @brief Configuração da base de dados e sessão
 * @details Inicia a sessão e estabelece ligação à base de dados MySQL
 */

// Iniciar sessão se ainda não estiver iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Configuração da base de dados
$host = 'localhost';
$db   = 'geo_dados';
$user = 'root';          // ALTERE para o seu utilizador MySQL
$pass = '';              // ALTERE para a sua password MySQL
$charset = 'utf8mb4';

// Data Source Name
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

// Opções do PDO
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

// Criar ligação global $pdo
try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    // Em produção, não mostrar detalhes do erro
    error_log("Erro de ligação à BD: " . $e->getMessage());
    die("Erro na ligação à base de dados. Por favor, tente mais tarde.");
}
?>
