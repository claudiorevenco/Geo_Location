<?php
/**
 * @file auth.php
 * @brief Funções de autenticação e permissões
 */

require_once 'config.php';

/**
 * Verifica se o utilizador está logado
 */
function isLoggedIn(): bool {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Verifica se o utilizador é administrador
 */
function isAdmin(): bool {
    return isLoggedIn() && isset($_SESSION['user_tipo']) && $_SESSION['user_tipo'] === 'admin';
}

/**
 * Obtém o tipo de utilizador
 */
function getUserType(): string {
    return $_SESSION['user_tipo'] ?? 'guest';
}

/**
 * Obtém o ID do utilizador
 */
function getUserId(): int {
    return $_SESSION['user_id'] ?? 0;
}

/**
 * Obtém o nome do utilizador
 */
function getUserName(): string {
    return $_SESSION['user_nome'] ?? 'Convidado';
}

/**
 * Redireciona para login se não estiver logado
 */
function requireLogin(): void {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}

/**
 * Redireciona se não for admin
 */
function requireAdmin(): void {
    if (!isAdmin()) {
        header('Location: index.php');
        exit;
    }
}

/**
 * Verifica se pode editar um local
 */
function canEditLocal($local_id, $pdo): bool {
    if (!isLoggedIn()) return false;
    if (isAdmin()) return true;

    $stmt = $pdo->prepare("SELECT criado_por FROM locais WHERE id = ?");
    $stmt->execute([$local_id]);
    $criador = $stmt->fetchColumn();
    return ($criador == $_SESSION['user_id']);
}
?>