<?php

/**
 * @file admin/utilizadores.php
 * @brief Gestão de utilizadores (CRUD completo) - Apenas Admin
 */
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/hash.php';

// Verificar se é admin
if (!isAdmin()) {
    header('Location: ../index.php');
    exit;
}

// Configurações de paginação
$porPagina = 10;
$pagina = isset($_GET['pagina']) ? max(1, intval($_GET['pagina'])) : 1;
$offset = ($pagina - 1) * $porPagina;

// Pesquisa
$pesquisa = trim($_GET['pesquisa'] ?? '');
$where = '';
$params = [];

if (!empty($pesquisa)) {
    $where = "WHERE (nome LIKE ? OR email LIKE ?)";
    $params = ["%$pesquisa%", "%$pesquisa%"];
}

// Contar total
$countSql = "SELECT COUNT(*) FROM utilizadores $where";
$stmt = $pdo->prepare($countSql);
$stmt->execute($params);
$totalRegistos = $stmt->fetchColumn();
$totalPaginas = ceil($totalRegistos / $porPagina);

// Buscar utilizadores
$sql = "SELECT id, nome, email, tipo, ativo, criado_em 
        FROM utilizadores 
        $where 
        ORDER BY criado_em DESC 
        LIMIT $porPagina OFFSET $offset";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$utilizadores = $stmt->fetchAll();

// Mensagens
$sucesso = $_SESSION['sucesso'] ?? '';
$erro = $_SESSION['erro'] ?? '';
unset($_SESSION['sucesso'], $_SESSION['erro']);

// Tipos permitidos
$tipos = ['normal' => 'Normal', 'admin' => 'Administrador'];

$user_nome = $_SESSION['user_nome'] ?? 'Admin';
$iniciais = implode('', array_map(function ($n) {
    return strtoupper($n[0]);
}, explode(' ', $user_nome, 2)));
?>
<!DOCTYPE html>
<html lang="pt">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerir Utilizadores - GeoLocation Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .admin-layout {
            display: flex;
            min-height: 100vh;
        }

        .admin-main {
            flex: 1;
            margin-left: 280px;
            padding: 32px;
            background: var(--gray-100);
            min-height: 100vh;
        }

        .admin-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
        }

        .admin-title {
            font-family: var(--font-display);
            font-size: 2rem;
            font-weight: 700;
            color: var(--gray-900);
        }

        .admin-card {
            background: var(--white);
            border-radius: var(--radius-xl);
            padding: 24px;
            box-shadow: var(--shadow);
            padding-bottom: 0.1rem;
        }

        .toolbar {
            display: flex;
            gap: 16px;
            margin-bottom: 24px;
            flex-wrap: wrap;
        }

        .search-box {
            position: relative;
            flex: 1;
            min-width: 300px;
        }

        .search-box input {
            width: 100%;
            padding: 12px 16px 12px 44px;
            border: 2px solid var(--gray-200);
            border-radius: var(--radius);
            font-size: 1rem;
        }

        .search-box i {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray-400);
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
        }

        .data-table th {
            text-align: left;
            padding: 16px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--gray-500);
            border-bottom: 2px solid var(--gray-200);
        }

        .data-table td {
            padding: 16px;
            border-bottom: 1px solid var(--gray-100);
            vertical-align: middle;
        }

        .data-table tr:hover {
            background: var(--gray-50);
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .user-avatar-sm {
            width: 40px;
            height: 40px;
            background: var(--gradient-primary);
            border-radius: var(--radius-full);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 0.9rem;
        }

        .user-details h4 {
            font-weight: 600;
            color: var(--gray-900);
            margin-bottom: 2px;
        }

        .user-details p {
            font-size: 0.85rem;
            color: var(--gray-500);
        }

        .badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            border-radius: var(--radius-full);
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
        }

        .badge-admin {
            background: #fef3c7;
            color: #92400e;
        }

        .badge-normal {
            background: #e0e7ff;
            color: #3730a3;
        }

        .badge-ativo {
            background: #d1fae5;
            color: #065f46;
        }

        .badge-inativo {
            background: #fee2e2;
            color: #991b1b;
        }

        .actions {
            display: flex;
            gap: 8px;
        }

        .btn-icon-sm {
            width: 36px;
            height: 36px;
            border: none;
            border-radius: var(--radius);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: var(--transition);
        }

        .btn-edit {
            background: #e0e7ff;
            color: var(--primary);
        }

        .btn-edit:hover {
            background: var(--primary);
            color: white;
        }

        .btn-delete {
            background: #fee2e2;
            color: var(--danger);
        }

        .btn-delete:hover {
            background: var(--danger);
            color: white;
        }

        .btn-view {
            background: var(--gray-100);
            color: var(--gray-600);
        }

        .btn-view:hover {
            background: var(--gray-200);
            color: var(--gray-900);
        }

        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 8px;
            margin-top: 24px;
        }

        .pagination a,
        .pagination span {
            padding: 8px 16px;
            border-radius: var(--radius);
            text-decoration: none;
            font-weight: 500;
        }

        .pagination a {
            background: var(--white);
            color: var(--gray-700);
            border: 1px solid var(--gray-200);
        }

        .pagination a:hover {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .pagination .current {
            background: var(--primary);
            color: white;
        }

        .pagination .disabled {
            color: var(--gray-400);
            cursor: not-allowed;
        }

        .empty-state {
            text-align: center;
            padding: 64px 24px;
        }

        .empty-state i {
            font-size: 4rem;
            color: var(--gray-300);
            margin-bottom: 16px;
        }

        .empty-state h3 {
            color: var(--gray-700);
            margin-bottom: 8px;
        }

        .empty-state p {
            color: var(--gray-500);
        }

        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }

        .modal-overlay.show {
            display: flex;
        }

        .modal-sm {
            background: white;
            border-radius: var(--radius-xl);
            width: 90%;
            max-width: 500px;
            max-height: 90vh;
            overflow-y: auto;
        }

        .modal-header-sm {
            padding: 24px;
            border-bottom: 1px solid var(--gray-200);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-body-sm {
            padding: 24px;
        }

        .modal-footer-sm {
            padding: 24px;
            border-top: 1px solid var(--gray-200);
            display: flex;
            justify-content: flex-end;
            gap: 12px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            font-size: 0.875rem;
            font-weight: 600;
            color: var(--gray-700);
            margin-bottom: 8px;
        }

        .form-input {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid var(--gray-200);
            border-radius: var(--radius);
            font-size: 1rem;
            transition: var(--transition);
        }

        .form-input:focus {
            outline: none;
            border-color: var(--primary);
        }

        .form-select {
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg ' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='%2364748b' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 12px center;
            background-size: 20px;
            padding-right: 44px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 32px;
        }

        .stat-card {
            background: var(--white);
            padding: 24px;
            border-radius: var(--radius-xl);
            box-shadow: var(--shadow);
        }

        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary);
        }

        .stat-label {
            color: var(--gray-500);
            font-size: 0.875rem;
        }

        @media (max-width: 768px) {
            .admin-main {
                margin-left: 0;
                padding: 20px;
            }

            .toolbar {
                flex-direction: column;
            }

            .search-box {
                min-width: 100%;
            }

            .data-table {
                font-size: 0.875rem;
            }

            .data-table th,
            .data-table td {
                padding: 12px 8px;
            }

            .user-avatar-sm {
                width: 32px;
                height: 32px;
                font-size: 0.75rem;
            }
        }
    </style>
</head>

<body>
    <div class="admin-layout">
        <!-- Sidebar (igual ao index mas com link ativo) -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <a href="../index.php" class="sidebar-brand">
                    <div class="sidebar-brand-icon">
                        <i class="fas fa-map-marked-alt"></i>
                    </div>
                    <span class="sidebar-brand-text">GeoLocation</span>
                </a>
            </div>

            <div class="sidebar-user">
                <div class="user-card">
                    <div class="user-avatar"><?= htmlspecialchars($iniciais) ?></div>
                    <div class="user-info">
                        <div class="user-name"><?= htmlspecialchars($user_nome) ?></div>
                        <div class="user-role">Administrador</div>
                    </div>
                </div>
            </div>

            <nav class="sidebar-nav">
                <div class="nav-section">
                    <div class="nav-section-title">Menu Principal</div>
                    <a href="../index.php" class="nav-item">
                        <i class="fas fa-map"></i>
                        <span>Mapa</span>
                    </a>
                    <a href="#" class="nav-item" onclick="alert('Funcionalidade em desenvolvimento'); return false;">
                        <i class="fas fa-map-pin"></i>
                        <span>Meus Locais</span>
                    </a>
                </div>

                <div class="nav-section">
                    <div class="nav-section-title">Administração</div>
                    <a href="utilizadores.php" class="nav-item active">
                        <i class="fas fa-users-cog" style="color: var(--primary)"></i>
                        <span>Utilizadores</span>
                    </a>
                    <a href="#" class="nav-item" onclick="alert('Funcionalidade em desenvolvimento'); return false;">
                        <i class="fas fa-layer-group" style="color: var(--secondary)"></i>
                        <span>Categorias</span>
                    </a>
                    <a href="#" class="nav-item" onclick="alert('Funcionalidade em desenvolvimento'); return false;">
                        <i class="fas fa-globe" style="color: var(--accent)"></i>
                        <span>Países & Cidades</span>
                    </a>
                </div>
            </nav>

            <div class="sidebar-footer">
                <a href="../logout.php" class="btn-logout">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Sair</span>
                </a>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="admin-main">
            <div class="admin-header">
                <h1 class="admin-title">👥 Gerir Utilizadores</h1>
            </div>

            <!-- Estatísticas -->
            <div class="stats-grid">
                <?php
                $total = $pdo->query("SELECT COUNT(*) FROM utilizadores")->fetchColumn();
                $ativos = $pdo->query("SELECT COUNT(*) FROM utilizadores WHERE ativo = 1")->fetchColumn();
                $admins = $pdo->query("SELECT COUNT(*) FROM utilizadores WHERE tipo = 'admin'")->fetchColumn();
                $novosMes = $pdo->query("SELECT COUNT(*) FROM utilizadores WHERE criado_em >= DATE_SUB(NOW(), INTERVAL 30 DAY)")->fetchColumn();
                ?>
                <div class="stat-card">
                    <div class="stat-value"><?= $total ?></div>
                    <div class="stat-label">Total Utilizadores</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value" style="color: var(--success)"><?= $ativos ?></div>
                    <div class="stat-label">Ativos</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value" style="color: var(--warning)"><?= $admins ?></div>
                    <div class="stat-label">Administradores</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value" style="color: var(--secondary)"><?= $novosMes ?></div>
                    <div class="stat-label">Novos (30 dias)</div>
                </div>
            </div>

            <!-- Mensagens -->
            <?php if ($sucesso): ?>
                <div class="alert alert-success" style="margin-bottom: 24px;">
                    <i class="fas fa-check-circle"></i> <?= htmlspecialchars($sucesso) ?>
                </div>
            <?php endif; ?>
            <?php if ($erro): ?>
                <div class="alert alert-error" style="margin-bottom: 24px;">
                    <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($erro) ?>
                </div>
            <?php endif; ?>

            <div class="admin-card">
                <!-- Toolbar -->
                <div class="toolbar">
                    <form method="get" class="search-box">
                        <i class="fas fa-search"></i>
                        <input type="text" name="pesquisa" placeholder="Pesquisar por nome ou email..."
                            value="<?= htmlspecialchars($pesquisa) ?>">
                        <?php if ($pesquisa): ?>
                            <a href="?" style="position: absolute; right: 16px; top: 50%; transform: translateY(-50%); color: var(--gray-400);">
                                <i class="fas fa-times"></i>
                            </a>
                        <?php endif; ?>
                    </form>
                </div>

                <!-- Tabela -->
                <?php if (count($utilizadores) > 0): ?>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Utilizador</th>
                                <th>Tipo</th>
                                <th>Estado</th>
                                <th>Registado</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($utilizadores as $u):
                                $iniciaisU = implode('', array_map(function ($n) {
                                    return strtoupper($n[0]);
                                }, explode(' ', $u['nome'], 2)));
                            ?>
                                <tr>
                                    <td>
                                        <div class="user-info">
                                            <div class="user-avatar-sm"><?= htmlspecialchars($iniciaisU) ?></div>
                                            <div class="user-details">
                                                <h4><?= htmlspecialchars($u['nome']) ?></h4>
                                                <p><?= htmlspecialchars($u['email']) ?></p>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span class="badge badge-<?= $u['tipo'] ?>">
                                            <i class="fas fa-<?= $u['tipo'] === 'admin' ? 'shield-alt' : 'user' ?>"></i>
                                            <?= $tipos[$u['tipo']] ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge badge-<?= $u['ativo'] ? 'ativo' : 'inativo' ?>">
                                            <i class="fas fa-<?= $u['ativo'] ? 'check' : 'times' ?>"></i>
                                            <?= $u['ativo'] ? 'Ativo' : 'Inativo' ?>
                                        </span>
                                    </td>
                                    <td><?= date('d/m/Y H:i', strtotime($u['criado_em'])) ?></td>
                                    <td>
                                        <div class="actions">
                                            <button class="btn-icon-sm btn-view" onclick="verUtilizador(<?= $u['id'] ?>)" title="Ver detalhes">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                            <button class="btn-icon-sm btn-edit" onclick="editarUtilizador(<?= $u['id'] ?>)" title="Editar">
                                                <i class="fas fa-edit"></i>
                                            </button>
                                            <?php if ($u['id'] != $_SESSION['user_id']): ?>
                                                <button class="btn-icon-sm btn-delete" onclick="confirmarEliminar(<?= $u['id'] ?>, '<?= htmlspecialchars(addslashes($u['nome'])) ?>')" title="Eliminar">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <div class="admin-header" style="margin-top: 1.5rem;">
                        <button class="btn btn-primary" onclick="abrirModalCriar()">
                            <i class="fas fa-plus"></i> Novo Utilizador
                        </button>
                    </div>


                    <!-- Paginação -->
                    <?php if ($totalPaginas > 1): ?>
                        <div class="pagination">
                            <?php if ($pagina > 1): ?>
                                <a href="?pagina=<?= $pagina - 1 ?><?= $pesquisa ? '&pesquisa=' . urlencode($pesquisa) : '' ?>">
                                    <i class="fas fa-chevron-left"></i>
                                </a>
                            <?php else: ?>
                                <span class="disabled"><i class="fas fa-chevron-left"></i></span>
                            <?php endif; ?>

                            <?php for ($i = max(1, $pagina - 2); $i <= min($totalPaginas, $pagina + 2); $i++): ?>
                                <?php if ($i == $pagina): ?>
                                    <span class="current"><?= $i ?></span>
                                <?php else: ?>
                                    <a href="?pagina=<?= $i ?><?= $pesquisa ? '&pesquisa=' . urlencode($pesquisa) : '' ?>"><?= $i ?></a>
                                <?php endif; ?>
                            <?php endfor; ?>

                            <?php if ($pagina < $totalPaginas): ?>
                                <a href="?pagina=<?= $pagina + 1 ?><?= $pesquisa ? '&pesquisa=' . urlencode($pesquisa) : '' ?>">
                                    <i class="fas fa-chevron-right"></i>
                                </a>
                            <?php else: ?>
                                <span class="disabled"><i class="fas fa-chevron-right"></i></span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-users-slash"></i>
                        <h3>Nenhum utilizador encontrado</h3>
                        <p><?= $pesquisa ? 'Tente ajustar os termos da pesquisa.' : 'Ainda não existem utilizadores registados.' ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <!-- Modal Criar -->
    <div id="modal-criar" class="modal-overlay">
        <div class="modal-sm">
            <div class="modal-header-sm">
                <h3><i class="fas fa-user-plus"></i> Novo Utilizador</h3>
                <button class="modal-close" onclick="fecharModal('modal-criar')">&times;</button>
            </div>
            <form action="utilizadores_action.php" method="post">
                <div class="modal-body-sm">
                    <input type="hidden" name="acao" value="criar">

                    <div class="form-group">
                        <label class="form-label">Nome completo *</label>
                        <input type="text" name="nome" class="form-input" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Email *</label>
                        <input type="email" name="email" class="form-input" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Senha *</label>
                        <input type="password" name="senha" class="form-input" required minlength="6">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Tipo *</label>
                        <select name="tipo" class="form-input form-select" required>
                            <option value="normal">Normal</option>
                            <option value="admin">Administrador</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer-sm">
                    <button type="button" class="btn btn-secondary" onclick="fecharModal('modal-criar')">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Criar Utilizador</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Editar -->
    <div id="modal-editar" class="modal-overlay">
        <div class="modal-sm">
            <div class="modal-header-sm">
                <h3><i class="fas fa-edit"></i> Editar Utilizador</h3>
                <button class="modal-close" onclick="fecharModal('modal-editar')">&times;</button>
            </div>
            <form action="utilizadores_action.php" method="post">
                <div class="modal-body-sm">
                    <input type="hidden" name="acao" value="editar">
                    <input type="hidden" name="id" id="edit-id">

                    <div class="form-group">
                        <label class="form-label">Nome completo *</label>
                        <input type="text" name="nome" id="edit-nome" class="form-input" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Email *</label>
                        <input type="email" name="email" id="edit-email" class="form-input" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Nova senha (deixar em branco para manter)</label>
                        <input type="password" name="senha" class="form-input" minlength="6" placeholder="••••••">
                    </div>

                    <div class="form-group">
                        <label class="form-label">Tipo *</label>
                        <select name="tipo" id="edit-tipo" class="form-input form-select" required>
                            <option value="normal">Normal</option>
                            <option value="admin">Administrador</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Estado *</label>
                        <select name="ativo" id="edit-ativo" class="form-input form-select" required>
                            <option value="1">Ativo</option>
                            <option value="0">Inativo</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer-sm">
                    <button type="button" class="btn btn-secondary" onclick="fecharModal('modal-editar')">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Guardar Alterações</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Ver -->
    <div id="modal-ver" class="modal-overlay">
        <div class="modal-sm">
            <div class="modal-header-sm">
                <h3><i class="fas fa-user"></i> Detalhes do Utilizador</h3>
                <button class="modal-close" onclick="fecharModal('modal-ver')">&times;</button>
            </div>
            <div class="modal-body-sm" id="ver-conteudo">
                <!-- Preenchido via JS -->
            </div>
            <div class="modal-footer-sm">
                <button type="button" class="btn btn-secondary" onclick="fecharModal('modal-ver')">Fechar</button>
            </div>
        </div>
    </div>

    <!-- Modal Eliminar -->
    <div id="modal-eliminar" class="modal-overlay">
        <div class="modal-sm">
            <div class="modal-header-sm" style="border-bottom-color: var(--danger);">
                <h3 style="color: var(--danger);"><i class="fas fa-exclamation-triangle"></i> Confirmar Eliminação</h3>
                <button class="modal-close" onclick="fecharModal('modal-eliminar')">&times;</button>
            </div>
            <form action="utilizadores_action.php" method="post">
                <div class="modal-body-sm">
                    <input type="hidden" name="acao" value="eliminar">
                    <input type="hidden" name="id" id="delete-id">

                    <p>Tem a certeza que deseja eliminar o utilizador <strong id="delete-nome"></strong>?</p>
                    <p style="color: var(--danger); font-size: 0.875rem; margin-top: 12px;">
                        <i class="fas fa-info-circle"></i> Esta ação não pode ser desfeita.
                    </p>
                </div>
                <div class="modal-footer-sm">
                    <button type="button" class="btn btn-secondary" onclick="fecharModal('modal-eliminar')">Cancelar</button>
                    <button type="submit" class="btn btn-danger" style="background: var(--danger); color: white;">Eliminar</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function editarUtilizador(id) {
    console.log('A editar utilizador:', id); // Debug
    
    fetch(`utilizadores_api.php?acao=ver&id=${id}`)
        .then(r => {
            console.log('Resposta HTTP:', r.status); // Debug
            if (!r.ok) throw new Error('Erro HTTP: ' + r.status);
            return r.json();
        })
        .then(data => {
            console.log('Dados recebidos:', data); // Debug
            
            if (data.success) {
                document.getElementById('edit-id').value = data.user.id;
                document.getElementById('edit-nome').value = data.user.nome;
                document.getElementById('edit-email').value = data.user.email;
                document.getElementById('edit-tipo').value = data.user.tipo;
                document.getElementById('edit-ativo').value = data.user.ativo;
                abrirModal('modal-editar');
            } else {
                alert('Erro: ' + (data.message || 'Não foi possível carregar os dados'));
            }
        })
        .catch(err => {
            console.error('Erro:', err);
            alert('Erro ao carregar dados: ' + err.message);
        });
}
        function abrirModal(id) {
            document.getElementById(id).classList.add('show');
        }

        function fecharModal(id) {
            document.getElementById(id).classList.remove('show');
        }

        function abrirModalCriar() {
            abrirModal('modal-criar');
        }

        function editarUtilizador(id) {
            // Buscar dados via AJAX
            fetch(`utilizadores_api.php?acao=ver&id=${id}`)
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        document.getElementById('edit-id').value = data.user.id;
                        document.getElementById('edit-nome').value = data.user.nome;
                        document.getElementById('edit-email').value = data.user.email;
                        document.getElementById('edit-tipo').value = data.user.tipo;
                        document.getElementById('edit-ativo').value = data.user.ativo;
                        abrirModal('modal-editar');
                    }
                });
        }

        function verUtilizador(id) {
            fetch(`utilizadores_api.php?acao=ver&id=${id}`)
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        const u = data.user;
                        const html = `
                            <div style="text-align: center; margin-bottom: 24px;">
                                <div style="width: 80px; height: 80px; background: var(--gradient-primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px; color: white; font-size: 2rem; font-weight: 600;">
                                    ${u.nome.split(' ').map(n => n[0].toUpperCase()).slice(0,2).join('')}
                                </div>
                                <h3 style="margin-bottom: 4px;">${u.nome}</h3>
                                <p style="color: var(--gray-500);">${u.email}</p>
                            </div>
                            <div style="display: grid; gap: 12px;">
                                <div style="display: flex; justify-content: space-between; padding: 12px; background: var(--gray-50); border-radius: var(--radius);">
                                    <span style="color: var(--gray-500);">Tipo</span>
                                    <span style="font-weight: 600; text-transform: capitalize;">${u.tipo}</span>
                                </div>
                                <div style="display: flex; justify-content: space-between; padding: 12px; background: var(--gray-50); border-radius: var(--radius);">
                                    <span style="color: var(--gray-500);">Estado</span>
                                    <span style="font-weight: 600;">${u.ativo ? 'Ativo' : 'Inativo'}</span>
                                </div>
                                <div style="display: flex; justify-content: space-between; padding: 12px; background: var(--gray-50); border-radius: var(--radius);">
                                    <span style="color: var(--gray-500);">Registado em</span>
                                    <span style="font-weight: 600;">${new Date(u.criado_em).toLocaleDateString('pt-PT')}</span>
                                </div>
                            </div>
                        `;
                        document.getElementById('ver-conteudo').innerHTML = html;
                        abrirModal('modal-ver');
                    }
                });
        }

        function confirmarEliminar(id, nome) {
            document.getElementById('delete-id').value = id;
            document.getElementById('delete-nome').textContent = nome;
            abrirModal('modal-eliminar');
        }

        // Fechar modais ao clicar fora
        document.querySelectorAll('.modal-overlay').forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) fecharModal(modal.id);
            });
        });
    </script>
</body>

</html>