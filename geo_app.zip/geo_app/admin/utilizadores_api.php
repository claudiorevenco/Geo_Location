<?php
/**
 * @file admin/utilizadores_api.php
 * @brief API para operações AJAX de utilizadores
 */
require_once '../includes/config.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

// Verificar se é admin
if (!isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Acesso negado']);
    exit;
}

$acao = $_GET['acao'] ?? '';
$id = intval($_GET['id'] ?? 0);

if ($acao !== 'ver' || $id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Parâmetros inválidos']);
    exit;
}

// Buscar utilizador
$stmt = $pdo->prepare("SELECT id, nome, email, tipo, ativo, criado_em FROM utilizadores WHERE id = ?");
$stmt->execute([$id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo json_encode(['success' => false, 'message' => 'Utilizador não encontrado']);
    exit;
}

echo json_encode(['success' => true, 'user' => $user]);