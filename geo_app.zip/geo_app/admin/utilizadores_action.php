<?php
/**
 * @file admin/utilizadores_action.php
 * @brief Processa ações CRUD de utilizadores
 */
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/hash.php';

// Verificar se é admin
if (!isAdmin()) {
    header('Location: ../index.php');
    exit;
}

$acao = $_POST['acao'] ?? '';

switch ($acao) {
    case 'criar':
        $nome = trim($_POST['nome'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $senha = $_POST['senha'] ?? '';
        $tipo = $_POST['tipo'] ?? 'normal';

        if (empty($nome) || empty($email) || empty($senha)) {
            $_SESSION['erro'] = 'Todos os campos são obrigatórios.';
            header('Location: utilizadores.php');
            exit;
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['erro'] = 'Email inválido.';
            header('Location: utilizadores.php');
            exit;
        }

        // Verificar se email existe
        $stmt = $pdo->prepare("SELECT id FROM utilizadores WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $_SESSION['erro'] = 'Email já registado.';
            header('Location: utilizadores.php');
            exit;
        }

        // Criar utilizador com SHA3
        $hash = hashPassword($senha);
        $stmt = $pdo->prepare("INSERT INTO utilizadores (nome, email, senha, tipo, ativo) VALUES (?, ?, ?, ?, 1)");
        
        if ($stmt->execute([$nome, $email, $hash, $tipo])) {
            $_SESSION['sucesso'] = 'Utilizador criado com sucesso!';
        } else {
            $_SESSION['erro'] = 'Erro ao criar utilizador.';
        }
        break;

    case 'editar':
        $id = intval($_POST['id'] ?? 0);
        $nome = trim($_POST['nome'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $senha = $_POST['senha'] ?? '';
        $tipo = $_POST['tipo'] ?? 'normal';
        $ativo = intval($_POST['ativo'] ?? 1);

        if ($id <= 0 || empty($nome) || empty($email)) {
            $_SESSION['erro'] = 'Dados inválidos.';
            header('Location: utilizadores.php');
            exit;
        }

        // Verificar se email já existe (exceto o próprio)
        $stmt = $pdo->prepare("SELECT id FROM utilizadores WHERE email = ? AND id != ?");
        $stmt->execute([$email, $id]);
        if ($stmt->fetch()) {
            $_SESSION['erro'] = 'Email já está em uso.';
            header('Location: utilizadores.php');
            exit;
        }

        // Não permitir desativar a si próprio
        if ($id == $_SESSION['user_id'] && $ativo == 0) {
            $_SESSION['erro'] = 'Não pode desativar a sua própria conta.';
            header('Location: utilizadores.php');
            exit;
        }

        // Atualizar
        if (!empty($senha)) {
            // Com nova senha
            $hash = hashPassword($senha);
            $stmt = $pdo->prepare("UPDATE utilizadores SET nome = ?, email = ?, senha = ?, tipo = ?, ativo = ? WHERE id = ?");
            $result = $stmt->execute([$nome, $email, $hash, $tipo, $ativo, $id]);
        } else {
            // Sem alterar senha
            $stmt = $pdo->prepare("UPDATE utilizadores SET nome = ?, email = ?, tipo = ?, ativo = ? WHERE id = ?");
            $result = $stmt->execute([$nome, $email, $tipo, $ativo, $id]);
        }

        if ($result) {
            $_SESSION['sucesso'] = 'Utilizador atualizado com sucesso!';
        } else {
            $_SESSION['erro'] = 'Erro ao atualizar utilizador.';
        }
        break;

    case 'eliminar':
        $id = intval($_POST['id'] ?? 0);

        if ($id <= 0) {
            $_SESSION['erro'] = 'ID inválido.';
            header('Location: utilizadores.php');
            exit;
        }

        // Não permitir eliminar a si próprio
        if ($id == $_SESSION['user_id']) {
            $_SESSION['erro'] = 'Não pode eliminar a sua própria conta.';
            header('Location: utilizadores.php');
            exit;
        }

        $stmt = $pdo->prepare("DELETE FROM utilizadores WHERE id = ?");
        if ($stmt->execute([$id])) {
            $_SESSION['sucesso'] = 'Utilizador eliminado com sucesso!';
        } else {
            $_SESSION['erro'] = 'Erro ao eliminar utilizador.';
        }
        break;

    default:
        $_SESSION['erro'] = 'Ação inválida.';
}

header('Location: utilizadores.php');
exit;