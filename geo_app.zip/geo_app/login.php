<?php
/**
 * @file login.php
 * @brief Página de login com design moderno
 */

require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/hash.php'; // NOVO: incluir funções de hash

if (isLoggedIn()) {
    header('Location: index.php');
    exit;
}

$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $senha = $_POST['senha'] ?? '';

    if (!empty($email) && !empty($senha)) {
        $stmt = $pdo->prepare("SELECT id, nome, senha, tipo FROM utilizadores WHERE email = ? AND ativo = 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user) {
            $senhaValida = false;
            
            // Verificar se é hash SHA3 (novo formato) ou password_hash antigo
            if (isHashSHA3($user['senha'])) {
                // Novo sistema SHA3-512
                $senhaValida = verifyPassword($senha, $user['senha']);
            } else {
                // Sistema antigo password_hash (para compatibilidade)
                $senhaValida = password_verify($senha, $user['senha']);
                
                // Opcional: atualizar para SHA3 automaticamente
                if ($senhaValida) {
                    $novoHash = hashPassword($senha);
                    $stmtUpdate = $pdo->prepare("UPDATE utilizadores SET senha = ? WHERE id = ?");
                    $stmtUpdate->execute([$novoHash, $user['id']]);
                }
            }

            if ($senhaValida) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_nome'] = $user['nome'];
                $_SESSION['user_tipo'] = $user['tipo'];
                header('Location: index.php');
                exit;
            } else {
                $erro = 'Email ou senha inválidos.';
            }
        } else {
            $erro = 'Email ou senha inválidos.';
        }
    } else {
        $erro = 'Preencha todos os campos.';
    }
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - GeoLocation</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="auth-page">
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-logo">
                <div class="auth-logo-icon">
                    <i class="fas fa-map-marked-alt"></i>
                </div>
                <h1>GeoLocation</h1>
                <p>Explore e partilhe locais incríveis</p>
            </div>

            <?php if ($erro): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <?= htmlspecialchars($erro) ?>
                </div>
            <?php endif; ?>

            <form method="post">
                <div class="form-group">
                    <label class="form-label" for="email">Email</label>
                    <input type="email" name="email" id="email" class="form-input" 
                           placeholder="seu@email.com" required autofocus>
                </div>

                <div class="form-group">
                    <label class="form-label" for="senha">Senha</label>
                    <input type="password" name="senha" id="senha" class="form-input" 
                           placeholder="••••••••" required>
                </div>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-sign-in-alt"></i>
                    Entrar
                </button>
            </form>

            <div class="auth-footer">
                <p>Ainda não tem conta? <a href="register.php">Criar conta</a></p>
            </div>
        </div>
    </div>
</body>
</html>