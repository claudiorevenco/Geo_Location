<?php
/**
 * @file register.php
 * @brief Registo de novos utilizadores
 */

require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/hash.php'; // NOVO: incluir funções de hash

if (isLoggedIn()) {
    header('Location: index.php');
    exit;
}

$erro = '';
$sucesso = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';
    $confirmar = $_POST['confirmar_senha'] ?? '';

    if (empty($nome) || empty($email) || empty($senha)) {
        $erro = 'Todos os campos são obrigatórios.';
    } elseif ($senha !== $confirmar) {
        $erro = 'As passwords não coincidem.';
    } elseif (strlen($senha) < 6) {
        $erro = 'A password deve ter pelo menos 6 caracteres.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erro = 'Email inválido.';
    } else {
        // Verificar se email já existe
        $stmt = $pdo->prepare("SELECT id FROM utilizadores WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $erro = 'Email já registado.';
        } else {
            // NOVO: Usar SHA3-512 em vez de password_hash
            $hash = hashPassword($senha);
            
            $stmt = $pdo->prepare("INSERT INTO utilizadores (nome, email, senha, tipo, ativo) VALUES (?, ?, ?, 'normal', 1)");
            if ($stmt->execute([$nome, $email, $hash])) {
                $sucesso = 'Registo efetuado com sucesso! Já pode fazer login.';
            } else {
                $erro = 'Erro ao registar. Tente novamente.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registo - GeoLocation</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="auth-page-registar">
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-logo">
                <div class="auth-logo-icon">
                    <i class="fas fa-user-plus"></i>
                </div>
                <h1>Criar Conta</h1>
                <p>Junte-se à comunidade GeoLocation</p>
            </div>

            <?php if ($sucesso): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <?= htmlspecialchars($sucesso) ?>
                </div>
            <?php endif; ?>

            <?php if ($erro): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <?= htmlspecialchars($erro) ?>
                </div>
            <?php endif; ?>

            <form method="post">
                <div class="form-group">
                    <label class="form-label" for="nome">Nome completo</label>
                    <input type="text" name="nome" id="nome" class="form-input" 
                           placeholder="Seu nome" required value="<?= isset($_POST['nome']) ? htmlspecialchars($_POST['nome']) : '' ?>">
                </div>

                <div class="form-group">
                    <label class="form-label" for="email">Email</label>
                    <input type="email" name="email" id="email" class="form-input" 
                           placeholder="seu@email.com" required value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>">
                </div>

                <div class="form-group">
                    <label class="form-label" for="senha">Senha</label>
                    <input type="password" name="senha" id="senha" class="form-input" 
                           placeholder="Mínimo 6 caracteres" required minlength="6">
                </div>

                <div class="form-group">
                    <label class="form-label" for="confirmar_senha">Confirmar senha</label>
                    <input type="password" name="confirmar_senha" id="confirmar_senha" class="form-input" 
                           placeholder="Repita a senha" required>
                </div>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-user-plus"></i>
                    Criar Conta
                </button>
            </form>

            <div class="auth-footer">
                <p>Já tem conta? <a href="login.php">Entrar</a></p>
            </div>
        </div>
    </div>
</body>
</html>