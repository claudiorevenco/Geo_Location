<?php

/**
 * @file index.php
 * @brief Página principal com mapa Leaflet
 */
require_once 'includes/config.php';
require_once 'includes/auth.php';

requireLogin();

// Buscar dados para os dropdowns
$categorias = $pdo->query("SELECT id, nome, cor, icone FROM categorias WHERE ativo = 1 ORDER BY nome")->fetchAll();
$paises = $pdo->query("SELECT id, nome_pt, codigo_iso FROM paises WHERE ativo = 1 ORDER BY nome_pt")->fetchAll();

$user_tipo = getUserType();
$user_id = getUserId();
$user_nome = $_SESSION['user_nome'] ?? 'Utilizador';

// Iniciais para avatar
$iniciais = implode('', array_map(function ($n) {
    return strtoupper($n[0]);
}, explode(' ', $user_nome, 2)));
?>
<!DOCTYPE html>
<html lang="pt">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GeoLocation - Mapa Interativo</title>

    <!-- Leaflet CSS -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <div class="app-layout">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <a href="index.php" class="sidebar-brand">
                    <div class="sidebar-brand-icon">
                        <i class="fas fa-map-marked-alt"></i>
                    </div>
                    <span class="sidebar-brand-text">GeoLocation</span>
                </a>
            </div>

            <div class="sidebar-user">
                <div class="user-card">
                    <div class="user-avatar"><?= htmlspecialchars($iniciais) ?></div>
                    <div class="user-info">
                        <div class="user-name"><?= htmlspecialchars($user_nome) ?></div>
                        <div class="user-role"><?= htmlspecialchars($user_tipo) ?></div>
                    </div>
                </div>
            </div>

            <nav class="sidebar-nav">
                <div class="nav-section">
                    <div class="nav-section-title">Menu Principal</div>
                    <a href="index.php" class="nav-item active">
                        <i class="fas fa-map"></i>
                        <span>Mapa</span>
                    </a>
                    <a href="#" class="nav-item" onclick="mostrarMeusLocais(); return false;">
                        <i class="fas fa-map-pin"></i>
                        <span>Meus Locais</span>
                    </a>
                    <?php if (isAdmin()): ?>
                        <a href="admin/utilizadores.php" class="nav-item">
                            <i class="fas fa-users-cog" style="color: var(--primary)"></i>
                            <span>Gerir Utilizadores</span>
                        </a>
                    <?php endif; ?>
                </div>

                <div class="nav-section">
                    <div class="nav-section-title">Categorias</div>
                    <?php foreach ($categorias as $cat): ?>
                        <a href="#" class="nav-item" onclick="filtrarCategoria(<?= $cat['id'] ?>); return false;">
                            <i class="fas <?= htmlspecialchars($cat['icone'] ?? 'fa-map-marker-alt') ?>" style="color: <?= htmlspecialchars($cat['cor']) ?>"></i>
                            <span><?= htmlspecialchars($cat['nome']) ?></span>
                        </a>
                    <?php endforeach; ?>
                </div>
            </nav>

            <div class="sidebar-footer">
                <a href="logout.php" class="btn-logout">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Sair</span>
                </a>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <header class="top-bar">
                <div class="top-bar-title">
                    <h2>Mapa Interativo</h2>
                </div>
                <div class="top-bar-actions">
                    <button class="btn-icon" onclick="locarUtilizador()" title="Minha localização">
                        <i class="fas fa-crosshairs"></i>
                    </button>
                    <button class="btn-icon" onclick="recarregarMapa()" title="Atualizar">
                        <i class="fas fa-sync-alt"></i>
                    </button>
                </div>
            </header>

            <div class="map-wrapper">
                <div id="map"></div>
            </div>
        </main>
    </div>

    <!-- Floating Action Button -->
    <button class="fab" onclick="abrirModalInserir()" title="Adicionar local">
        <i class="fas fa-plus"></i>
    </button>

    <!-- Modal Inserir Local -->
    <div id="modal-inserir" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title"><i class="fas fa-plus-circle"></i> Novo Local</h3>
                <button class="modal-close" onclick="fecharModal('modal-inserir')">&times;</button>
            </div>
            <div class="modal-body">
                <form id="form-inserir" enctype="multipart/form-data">
                    <input type="hidden" name="latitude" id="latitude">
                    <input type="hidden" name="longitude" id="longitude">

                    <div class="form-grid">
                        <div class="form-group full-width">
                            <label class="form-label" for="nome">Nome do Local *</label>
                            <input type="text" name="nome" id="nome" class="form-input" required
                                placeholder="Ex: Praia da Califórnia">
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="categoria_id">Categoria *</label>
                            <select name="categoria_id" id="categoria_id" class="form-input form-select" required>
                                <option value="">Selecione...</option>
                                <?php foreach ($categorias as $c): ?>
                                    <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['nome']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="pais_id">País *</label>
                            <select name="pais_id" id="pais_id" class="form-input form-select" required>
                                <option value="">Selecione...</option>
                                <?php foreach ($paises as $p): ?>
                                    <option value="<?= $p['id'] ?>" data-iso="<?= $p['codigo_iso'] ?>">
                                        <?= htmlspecialchars($p['nome_pt']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="cidade_id">Cidade *</label>
                            <select name="cidade_id" id="cidade_id" class="form-input form-select" required disabled>
                                <option value="">Selecione um país primeiro</option>
                            </select>
                        </div>

                        <div class="form-group full-width">
                            <label class="form-label" for="morada">Morada completa *</label>
                            <input type="text" name="morada" id="morada" class="form-input" required
                                placeholder="Rua, número, andar...">
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="codigo_postal">Código Postal *</label>
                            <input type="text" name="codigo_postal" id="codigo_postal" class="form-input" required
                                placeholder="0000-000">
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="telefone">Telefone</label>
                            <input type="tel" name="telefone" id="telefone" class="form-input"
                                placeholder="+351 000 000 000">
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="email">Email</label>
                            <input type="email" name="email" id="email" class="form-input"
                                placeholder="contacto@exemplo.pt">
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="website">Website</label>
                            <input type="url" name="website" id="website" class="form-input"
                                placeholder="https://www.exemplo.pt">
                        </div>

                        <div class="form-group full-width">
                            <label class="form-label" for="descricao_curta">Descrição curta</label>
                            <input type="text" name="descricao_curta" id="descricao_curta" class="form-input"
                                maxlength="255" placeholder="Breve resumo do local (max 255 caracteres)">
                        </div>

                        <div class="form-group full-width">
                            <label class="form-label" for="descricao">Descrição completa</label>
                            <textarea name="descricao" id="descricao" class="form-input form-textarea" rows="4"
                                placeholder="Descrição detalhada do local..."></textarea>
                        </div>

                        <div class="form-group full-width">
                            <label class="form-label" for="foto">Fotografia</label>
                            <input type="file" name="foto" id="foto" class="form-input form-file"
                                accept="image/*">
                            <p class="form-hint">Formatos aceites: JPG, PNG, GIF (max 2MB)</p>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="fecharModal('modal-inserir')">Cancelar</button>
                <button type="button" class="btn btn-primary" onclick="submeterLocal()">
                    <i class="fas fa-save"></i> Guardar Local
                </button>
            </div>
        </div>
    </div>

    <!-- Modal Detalhes -->
    <div id="modal-detalhes" class="modal">
        <div class="modal-content modal-lg">
            <div class="modal-header">
                <h3 class="modal-title"><i class="fas fa-info-circle"></i> Detalhes do Local</h3>
                <button class="modal-close" onclick="fecharModal('modal-detalhes')">&times;</button>
            </div>
            <div class="modal-body" id="detalhes-conteudo">
                <!-- Conteúdo carregado via JS -->
            </div>
        </div>
    </div>

    <!-- Modal Editar -->
    <div id="modal-editar" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title"><i class="fas fa-edit"></i> Editar Local</h3>
                <button class="modal-close" onclick="fecharModal('modal-editar')">&times;</button>
            </div>
            <div class="modal-body">
                <form id="form-editar" enctype="multipart/form-data">
                    <input type="hidden" name="id" id="edit-id">
                    <input type="hidden" name="latitude" id="edit-latitude">
                    <input type="hidden" name="longitude" id="edit-longitude">

                    <div class="form-grid">
                        <div class="form-group full-width">
                            <label class="form-label" for="edit-nome">Nome do Local *</label>
                            <input type="text" name="nome" id="edit-nome" class="form-input" required>
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="edit-categoria_id">Categoria *</label>
                            <select name="categoria_id" id="edit-categoria_id" class="form-input form-select" required>
                                <option value="">Selecione...</option>
                                <?php foreach ($categorias as $c): ?>
                                    <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['nome']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="edit-pais_id">País *</label>
                            <select name="pais_id" id="edit-pais_id" class="form-input form-select" required>
                                <option value="">Selecione...</option>
                                <?php foreach ($paises as $p): ?>
                                    <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['nome_pt']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="edit-cidade_id">Cidade *</label>
                            <select name="cidade_id" id="edit-cidade_id" class="form-input form-select" required disabled>
                                <option value="">Selecione um país primeiro</option>
                            </select>
                        </div>

                        <div class="form-group full-width">
                            <label class="form-label" for="edit-morada">Morada *</label>
                            <input type="text" name="morada" id="edit-morada" class="form-input" required>
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="edit-codigo_postal">Código Postal *</label>
                            <input type="text" name="codigo_postal" id="edit-codigo_postal" class="form-input" required>
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="edit-telefone">Telefone</label>
                            <input type="tel" name="telefone" id="edit-telefone" class="form-input">
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="edit-email">Email</label>
                            <input type="email" name="email" id="edit-email" class="form-input">
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="edit-website">Website</label>
                            <input type="url" name="website" id="edit-website" class="form-input">
                        </div>

                        <div class="form-group full-width">
                            <label class="form-label" for="edit-descricao_curta">Descrição curta</label>
                            <input type="text" name="descricao_curta" id="edit-descricao_curta" class="form-input" maxlength="255">
                        </div>

                        <div class="form-group full-width">
                            <label class="form-label" for="edit-descricao">Descrição completa</label>
                            <textarea name="descricao" id="edit-descricao" class="form-input form-textarea" rows="4"></textarea>
                        </div>

                        <div class="form-group full-width">
                            <label class="form-label" for="edit-foto">Nova fotografia (opcional)</label>
                            <input type="file" name="foto" id="edit-foto" class="form-input form-file" accept="image/*">
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="fecharModal('modal-editar')">Cancelar</button>
                <button type="button" class="btn btn-primary" onclick="atualizarLocal()">
                    <i class="fas fa-save"></i> Guardar Alterações
                </button>
            </div>
        </div>
    </div>

    <!-- Leaflet JS -->
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

    <!-- App JS -->
    <script src="assets/js/script.js"></script>

    <script>
        // Variáveis globais para JavaScript
        const USER_TIPO = '<?= $user_tipo ?>';
        const USER_ID = <?= $user_id ?>;
        const USER_NOME = '<?= htmlspecialchars($user_nome) ?>';
    </script>
</body>

</html>