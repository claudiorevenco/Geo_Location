/**
 * @file script.js
 * @brief Lógica principal da aplicação GeoLocation
 */

// Variáveis globais
let map;
let markersLayer;
let tempMarker = null;
let allLocais = [];
let currentLocalId = null;
let currentFilter = 'all';

// Cache para Nominatim
const nominatimCache = {};

/**
 * Inicialização da aplicação
 */
document.addEventListener('DOMContentLoaded', function() {
    initMap();
    carregarLocais();
    setupEventListeners();
});

/**
 * Inicializa o mapa Leaflet
 */
function initMap() {
    // Centro em Portugal
    map = L.map('map').setView([39.5, -8.0], 7);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors',
        maxZoom: 19
    }).addTo(map);

    markersLayer = L.layerGroup().addTo(map);

    // Evento de clique no mapa
    map.on('click', function(e) {
        abrirModalInserir(e.latlng);
    });
}

/**
 * Configura event listeners
 */
function setupEventListeners() {
    // Carregar cidades quando país muda (inserir)
    const paisSelect = document.getElementById('pais_id');
    if (paisSelect) {
        paisSelect.addEventListener('change', function() {
            carregarCidades(this.value, 'cidade_id');
        });
    }

    // Carregar cidades quando país muda (editar)
    const editPaisSelect = document.getElementById('edit-pais_id');
    if (editPaisSelect) {
        editPaisSelect.addEventListener('change', function() {
            carregarCidades(this.value, 'edit-cidade_id');
        });
    }

    // Fechar modais ao clicar fora
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                fecharModal(this.id);
            }
        });
    });
}

/**
 * Carrega cidades de um país
 */
function carregarCidades(paisId, selectId) {
    const select = document.getElementById(selectId);
    if (!select) return;

    if (!paisId) {
        select.innerHTML = '<option value="">Selecione um país primeiro</option>';
        select.disabled = true;
        return;
    }

    select.innerHTML = '<option value="">A carregar...</option>';
    select.disabled = true;

    fetch(`api/get_cidades.php?pais_id=${paisId}`)
        .then(r => {
            if (!r.ok) throw new Error('Erro na resposta');
            return r.json();
        })
        .then(cidades => {
            select.innerHTML = '<option value="">Selecione...</option>';
            cidades.forEach(c => {
                select.innerHTML += `<option value="${c.id}">${c.nome}</option>`;
            });
            select.disabled = false;
        })
        .catch(err => {
            console.error('Erro ao carregar cidades:', err);
            select.innerHTML = '<option value="">Erro ao carregar</option>';
        });
}

/**
 * Carrega todos os locais do servidor
 */
function carregarLocais() {
    fetch('api/get_locais.php')
        .then(r => {
            if (!r.ok) throw new Error('Erro na resposta');
            return r.json();
        })
        .then(data => {
            allLocais = data;
            atualizarMarcadores(data);
        })
        .catch(err => {
            console.error('Erro ao carregar locais:', err);
            mostrarNotificacao('Erro ao carregar locais', 'error');
        });
}

/**
 * Atualiza os marcadores no mapa
 */
function atualizarMarcadores(locais) {
    markersLayer.clearLayers();

    locais.forEach(local => {
        // Criar ícone customizado
        const iconHtml = `<div style="
            background: ${local.categoria_cor || '#6366f1'};
            width: 36px;
            height: 36px;
            border-radius: 50%;
            border: 3px solid white;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 14px;
        ">${local.categoria_letras || '?'}</div>`;

        const customIcon = L.divIcon({
            html: iconHtml,
            className: 'custom-marker',
            iconSize: [36, 36],
            iconAnchor: [18, 18]
        });

        const marker = L.marker([local.latitude, local.longitude], { icon: customIcon })
            .bindPopup(createPopupContent(local));

        markersLayer.addLayer(marker);
    });
}

/**
 * Cria conteúdo do popup
 */
function createPopupContent(local) {
    const fotoHtml = local.foto_principal ? 
        `<img src="uploads/${local.foto_principal}" style="width:100%;height:120px;object-fit:cover;border-radius:8px;margin-bottom:12px;">` : '';

    return `
        <div style="font-family: 'Plus Jakarta Sans', sans-serif; min-width: 280px;">
            ${fotoHtml}
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;">
                <div style="
                    background: ${local.categoria_cor || '#6366f1'};
                    width: 40px;
                    height: 40px;
                    border-radius: 10px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    color: white;
                    font-size: 18px;
                ">
                    <i class="fas ${local.categoria_icone || 'fa-map-marker-alt'}"></i>
                </div>
                <div>
                    <h4 style="margin:0;font-size:1.1rem;font-weight:700;color:#0f172a;">${local.nome}</h4>
                    <span style="font-size:0.85rem;color:#64748b;">${local.categoria}</span>
                </div>
            </div>
            <p style="margin:0 0 12px 0;font-size:0.9rem;color:#475569;">
                <i class="fas fa-map-marker-alt" style="color:#6366f1;margin-right:6px;"></i>
                ${local.morada}, ${local.cidade}
            </p>
            <button onclick="abrirDetalhes(${local.id})" style="
                width: 100%;
                padding: 10px;
                background: linear-gradient(135deg, #6366f1, #8b5cf6);
                color: white;
                border: none;
                border-radius: 8px;
                font-weight: 600;
                cursor: pointer;
                font-family: inherit;
            ">Ver detalhes</button>
        </div>
    `;
}

/**
 * Abre modal de inserção
 */
function abrirModalInserir(latlng = null) {
    const modal = document.getElementById('modal-inserir');
    const form = document.getElementById('form-inserir');

    form.reset();
    document.getElementById('cidade_id').innerHTML = '<option value="">Selecione um país primeiro</option>';
    document.getElementById('cidade_id').disabled = true;

    if (latlng) {
        document.getElementById('latitude').value = latlng.lat.toFixed(8);
        document.getElementById('longitude').value = latlng.lng.toFixed(8);

        // Marcador temporário
        if (tempMarker) map.removeLayer(tempMarker);
        tempMarker = L.marker([latlng.lat, latlng.lng]).addTo(map);

        // Tentar obter morada via Nominatim
        reverseGeocode(latlng.lat, latlng.lng);
    }

    modal.classList.add('show');
}

/**
 * Reverse geocoding
 */
function reverseGeocode(lat, lng) {
    const cacheKey = `${lat.toFixed(6)},${lng.toFixed(6)}`;

    if (nominatimCache[cacheKey]) {
        preencherMorada(nominatimCache[cacheKey]);
        return;
    }

    fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json&accept-language=pt`, {
        headers: { 'User-Agent': 'GeoLocation App' }
    })
    .then(r => r.json())
    .then(data => {
        if (data.address) {
            nominatimCache[cacheKey] = data.address;
            preencherMorada(data.address);
        }
    })
    .catch(err => console.error('Erro Nominatim:', err));
}

/**
 * Preenche campos de morada
 */
function preencherMorada(addr) {
    const rua = addr.road || addr.street || '';
    const numero = addr.house_number || '';
    let morada = rua;
    if (numero) morada += ', ' + numero;

    document.getElementById('morada').value = morada;
    document.getElementById('codigo_postal').value = addr.postcode || '';

    // Selecionar país
    const codigoPais = addr.country_code ? addr.country_code.toUpperCase() : '';
    if (codigoPais) {
        const paisSelect = document.getElementById('pais_id');
        const option = Array.from(paisSelect.options).find(opt => 
            opt.getAttribute('data-iso') === codigoPais
        );
        if (option) {
            paisSelect.value = option.value;
            paisSelect.dispatchEvent(new Event('change'));

            // Tentar selecionar cidade após carregar
            const cidadeNome = addr.city || addr.town || addr.village || addr.municipality || '';
            if (cidadeNome) {
                setTimeout(() => {
                    const cidadeSelect = document.getElementById('cidade_id');
                    const cidadeOpt = Array.from(cidadeSelect.options).find(opt => 
                        opt.text.toLowerCase().includes(cidadeNome.toLowerCase())
                    );
                    if (cidadeOpt) cidadeSelect.value = cidadeOpt.value;
                }, 500);
            }
        }
    }
}

/**
 * Submete novo local
 */
function submeterLocal() {
    const form = document.getElementById('form-inserir');

    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }

    const formData = new FormData(form);
    formData.append('criado_por', USER_ID);

    fetch('api/inserir_local.php', {
        method: 'POST',
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            mostrarNotificacao('Local adicionado com sucesso!', 'success');
            fecharModal('modal-inserir');
            carregarLocais();
            if (tempMarker) {
                map.removeLayer(tempMarker);
                tempMarker = null;
            }
        } else {
            mostrarNotificacao(data.message || 'Erro ao adicionar local', 'error');
        }
    })
    .catch(err => {
        console.error('Erro:', err);
        mostrarNotificacao('Erro de ligação', 'error');
    });
}

/**
 * Abre detalhes do local
 */
function abrirDetalhes(id) {
    const local = allLocais.find(l => l.id == id);
    if (!local) return;

    currentLocalId = id;
    const modal = document.getElementById('modal-detalhes');
    const conteudo = document.getElementById('detalhes-conteudo');

    const podeEditar = (USER_TIPO === 'admin' || local.criado_por == USER_ID);
    const fotoHtml = local.foto_principal ? 
        `<img src="uploads/${local.foto_principal}" class="detail-header-img">` : '';

    conteudo.innerHTML = `
        <div class="detail-header" style="${!local.foto_principal ? 'background: linear-gradient(135deg, ' + (local.categoria_cor || '#6366f1') + ', #8b5cf6);' : ''}">
            ${fotoHtml}
            <div class="detail-header-overlay">
                <span class="detail-category" style="background: ${local.categoria_cor || '#6366f1'}">
                    <i class="fas ${local.categoria_icone || 'fa-map-marker-alt'}"></i> ${local.categoria}
                </span>
                <h2 class="detail-title">${local.nome}</h2>
                <div class="detail-location">
                    <i class="fas fa-map-marker-alt"></i>
                    ${local.cidade}, ${local.pais}
                </div>
            </div>
        </div>

        <div class="detail-body">
            <div class="detail-section">
                <h4 class="detail-section-title">Informações de Contacto</h4>
                <div class="detail-info-grid">
                    <div class="detail-info-item">
                        <div class="detail-info-icon"><i class="fas fa-map-marker-alt"></i></div>
                        <div class="detail-info-content">
                            <div class="detail-info-label">Morada</div>
                            <div class="detail-info-value">${local.morada}<br>${local.codigo_postal}</div>
                        </div>
                    </div>
                    ${local.telefone ? `
                    <div class="detail-info-item">
                        <div class="detail-info-icon"><i class="fas fa-phone"></i></div>
                        <div class="detail-info-content">
                            <div class="detail-info-label">Telefone</div>
                            <div class="detail-info-value"><a href="tel:${local.telefone}">${local.telefone}</a></div>
                        </div>
                    </div>` : ''}
                    ${local.email ? `
                    <div class="detail-info-item">
                        <div class="detail-info-icon"><i class="fas fa-envelope"></i></div>
                        <div class="detail-info-content">
                            <div class="detail-info-label">Email</div>
                            <div class="detail-info-value"><a href="mailto:${local.email}">${local.email}</a></div>
                        </div>
                    </div>` : ''}
                    ${local.website ? `
                    <div class="detail-info-item">
                        <div class="detail-info-icon"><i class="fas fa-globe"></i></div>
                        <div class="detail-info-content">
                            <div class="detail-info-label">Website</div>
                            <div class="detail-info-value"><a href="${local.website}" target="_blank">Visitar site</a></div>
                        </div>
                    </div>` : ''}
                    <div class="detail-info-item">
                        <div class="detail-info-icon"><i class="fas fa-crosshairs"></i></div>
                        <div class="detail-info-content">
                            <div class="detail-info-label">Coordenadas</div>
                            <div class="detail-info-value">${local.latitude}, ${local.longitude}</div>
                        </div>
                    </div>
                </div>
            </div>

            ${local.descricao ? `
            <div class="detail-section">
                <h4 class="detail-section-title">Sobre</h4>
                <div class="detail-description">${local.descricao}</div>
            </div>` : ''}

            <div class="detail-actions">
                ${podeEditar ? `
                    <button class="btn-action btn-action-primary" onclick="abrirEditar(${local.id})">
                        <i class="fas fa-edit"></i> Editar
                    </button>
                    <button class="btn-action btn-action-danger" onclick="apagarLocal()">
                        <i class="fas fa-trash"></i> Apagar
                    </button>
                ` : ''}
                <button class="btn-action btn-action-secondary" onclick="toggleEmailForm()">
                    <i class="fas fa-envelope"></i> Enviar por Email
                </button>
            </div>

            <div id="email-form-container" class="email-form" style="display:none;">
                <div class="email-form-title">Enviar informações por email</div>
                <div class="email-form-row">
                    <input type="email" id="email-destino" class="form-input-email" placeholder="email@exemplo.com">
                    <button class="btn btn-primary" onclick="enviarEmail()">
                        <i class="fas fa-paper-plane"></i> Enviar
                    </button>
                </div>
            </div>
        </div>
    `;

    modal.classList.add('show');
}

/**
 * Abre modal de edição
 */
function abrirEditar(id) {
    const local = allLocais.find(l => l.id == id);
    if (!local) return;

    fecharModal('modal-detalhes');

    document.getElementById('edit-id').value = local.id;
    document.getElementById('edit-nome').value = local.nome;
    document.getElementById('edit-categoria_id').value = local.categoria_id;
    document.getElementById('edit-morada').value = local.morada;
    document.getElementById('edit-codigo_postal').value = local.codigo_postal;
    document.getElementById('edit-telefone').value = local.telefone || '';
    document.getElementById('edit-email').value = local.email || '';
    document.getElementById('edit-website').value = local.website || '';
    document.getElementById('edit-descricao_curta').value = local.descricao_curta || '';
    document.getElementById('edit-descricao').value = local.descricao || '';
    document.getElementById('edit-latitude').value = local.latitude;
    document.getElementById('edit-longitude').value = local.longitude;

    // Carregar país e cidade
    fetch(`api/get_cidade_pais.php?cidade_id=${local.cidade_id}`)
        .then(r => r.json())
        .then(data => {
            document.getElementById('edit-pais_id').value = data.pais_id;
            document.getElementById('edit-pais_id').dispatchEvent(new Event('change'));

            setTimeout(() => {
                document.getElementById('edit-cidade_id').value = local.cidade_id;
            }, 600);
        });

    document.getElementById('modal-editar').classList.add('show');
}

/**
 * Atualiza local
 */
function atualizarLocal() {
    const form = document.getElementById('form-editar');

    if (!form.checkValidity()) {
        form.reportValidity();
        return;
    }

    const formData = new FormData(form);
    formData.append('atualizado_por', USER_ID);

    fetch('api/editar_local.php', {
        method: 'POST',
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            mostrarNotificacao('Local atualizado com sucesso!', 'success');
            fecharModal('modal-editar');
            carregarLocais();
        } else {
            mostrarNotificacao(data.message || 'Erro ao atualizar', 'error');
        }
    })
    .catch(err => {
        console.error('Erro:', err);
        mostrarNotificacao('Erro de ligação', 'error');
    });
}

/**
 * Apaga local
 */
function apagarLocal() {
    
    fetch('api/apagar_local.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: currentLocalId })
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            mostrarNotificacao('Local apagado com sucesso!', 'success');
            fecharModal('modal-detalhes');
            carregarLocais();
        } else {
            mostrarNotificacao(data.message || 'Erro ao apagar', 'error');
        }
    })
    .catch(err => {
        console.error('Erro:', err);
        mostrarNotificacao('Erro de ligação', 'error');
    });
}

/**
 * Mostra/esconde formulário de email
 */
function toggleEmailForm() {
    const form = document.getElementById('email-form-container');
    form.style.display = form.style.display === 'none' ? 'block' : 'none';
}

/**
 * Envia email
 */
function enviarEmail() {
    const destino = document.getElementById('email-destino').value;

    if (!destino || !destino.includes('@')) {
        mostrarNotificacao('Introduza um email válido', 'error');
        return;
    }

    fetch('api/enviar_email.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: currentLocalId, email: destino })
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            mostrarNotificacao('Email enviado com sucesso!', 'success');
            document.getElementById('email-destino').value = '';
            toggleEmailForm();
        } else {
            mostrarNotificacao(data.message || 'Erro ao enviar email', 'error');
        }
    })
    .catch(err => {
        console.error('Erro:', err);
        mostrarNotificacao('Erro de ligação', 'error');
    });
}

/**
 * Fecha modal
 */
function fecharModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('show');
    }

    if (modalId === 'modal-inserir' && tempMarker) {
        map.removeLayer(tempMarker);
        tempMarker = null;
    }
}

/**
 * Localiza utilizador
 */
function locarUtilizador() {
    if (!navigator.geolocation) {
        mostrarNotificacao('Geolocalização não suportada', 'error');
        return;
    }

    navigator.geolocation.getCurrentPosition(
        pos => {
            const { latitude, longitude } = pos.coords;
            map.setView([latitude, longitude], 15);
            L.marker([latitude, longitude])
                .addTo(map)
                .bindPopup('A sua localização')
                .openPopup();
        },
        () => mostrarNotificacao('Não foi possível obter localização', 'error')
    );
}

/**
 * Recarrega mapa
 */
function recarregarMapa() {
    carregarLocais();
    mostrarNotificacao('Mapa atualizado', 'success');
}

/**
 * Filtra por categoria
 */
function filtrarCategoria(categoriaId) {
    const filtrados = allLocais.filter(l => l.categoria_id == categoriaId);
    atualizarMarcadores(filtrados);

    // Atualizar UI
    document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
    event.target.closest('.nav-item').classList.add('active');
}

/**
 * Mostra meus locais
 */
function mostrarMeusLocais() {
    const meus = allLocais.filter(l => l.criado_por == USER_ID);
    atualizarMarcadores(meus);
}


/**
 * Mostra notificação
 */
function mostrarNotificacao(mensagem, tipo = 'info') {
    // Criar elemento de notificação
    const notif = document.createElement('div');
    notif.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 16px 24px;
        border-radius: 12px;
        color: white;
        font-weight: 500;
        z-index: 10000;
        animation: slideInRight 0.3s ease;
        box-shadow: 0 10px 25px rgba(0,0,0,0.2);
    `;

    const cores = {
        success: '#10b981',
        error: '#ef4444',
        info: '#3b82f6',
        warning: '#f59e0b'
    };

    notif.style.background = cores[tipo] || cores.info;
    notif.textContent = mensagem;

    document.body.appendChild(notif);

    setTimeout(() => {
        notif.style.animation = 'fadeOut 0.3s ease';
        setTimeout(() => notif.remove(), 300);
    }, 3000);
}

// Adicionar animação de fadeOut
const style = document.createElement('style');
style.textContent = `
    @keyframes fadeOut {
        from { opacity: 1; transform: translateX(0); }
        to { opacity: 0; transform: translateX(20px); }
    }
`;
document.head.appendChild(style);
